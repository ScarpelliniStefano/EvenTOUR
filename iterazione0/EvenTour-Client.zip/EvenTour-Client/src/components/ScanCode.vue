<template>
    <div id="signup-form">
        <v-container fluid>
            <v-col>
                <v-text-field placeholder="Insert code...">
                </v-text-field>
            </v-col>
        </v-container>
    </div>
</template>

<script>
    export default {
        name:"ScanCode",
        date: () => ({

        })
    }
</script>

<style scoped>
</style>