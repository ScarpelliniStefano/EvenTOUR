<template>
<v-container>
  <div id="event-form">
    <v-btn style="float: right;" tile fab v-on:click="backHome()"> 
        <v-icon color="blue">mdi-home</v-icon>     
    </v-btn>
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-card-title>{{ eventData.title }}</v-card-title>
      <v-card-text>
        <div>{{ eventData.description }}</div>
        <div>{{ this.eventData.location.locality }}</div>
        <div>{{ this.eventData.location.city + " (" + this.eventData.location.sigla + ")" }}</div>
        <div>{{
                new Date(eventData.dataOra).getDate() +
                           "/" +
                new Date(eventData.dataOra).getMonth() +
                      "/" +
                new Date(eventData.dataOra).getFullYear() +
                      " h." +
                new Date(eventData.dataOra).getHours() +
                      ":" +
                new Date(eventData.dataOra).getMinutes()
             }}</div>
      </v-card-text>
    </v-card>

  </div>
  <v-container fluid>
    <list-ticket-manager :idEvent="this.idEvent"/>
  </v-container>
</v-container>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";
import ListTicketManager from "../components/ListTicketsManager.vue"

export default {
  name: "EventForm",
  data: () => ({
    eventData: Object,
    numSeat: Number,
    idEvent: String,
  }),
  props: {
    authManager: Boolean,
    idAccount: String,
  },
  components:{
    ListTicketManager
  },
  methods: {
    login() {
      this.$router.replace({ 
        name: "Login",
        params:{
          manEvId: this.idEvent
        } 
      });
    },
    backHome() {
      this.$router.replace({ name: "HomeManager" });
    },
    getEvent() {
      this.idEvent = this.$route.params.id;
      EvenTourDataService.getEventManager(this.idEvent).then((response) => {
        this.eventData = response.data;
      });
    },
    delBooking() {
      EvenTourDataService.getBookingEventOfUser(
        this.idAccount,
        this.idEvent
      ).then((responseUserEvent) => {
            EvenTourDataService.deleteBooking(responseUserEvent.data[0].id);
            this.book = false;
            this.numSeat = 0;
      });
    },
  },
  created() {
    //ADD function that retrieve data of event and booking
    //this.getEvent(this.$route.params.id);
  },
  mounted() {
    this.getEvent();
  },
};
</script>

<style scoped>
</style>