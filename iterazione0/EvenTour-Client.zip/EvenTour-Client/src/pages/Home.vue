<template>
  
  <div>
    <Main :auth="auth" />
  </div>
</template>

<script>
import Main from "../components/ListEvents.vue";

export default {
  name: "Home",

  components: {
    Main,
  },
  props: ["auth"],
  data: () => ({
    page: "0",
    size: "20",
    param: "",
    order: ""
  }),
  created() {
    if (this.getCookie("typeAccount") == "TicketInsp") {
      this.$router.replace({ name: "ScanCode" });
    }
    if(this.getCookie("typeAccount") == "Manager"){
      this.$router.replace({ name: "HomeManager"})
    }

  },
  mounted() {
  },
  methods: {
    getCookie(name) {
      var cookieArr = document.cookie.split(";");
      for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1]);
        }
      }
      return null;
    },
    logout() {
      this.$emit("auth", false);
      this.$router.replace({ name: "Home" });
    },
  },
};
</script>
