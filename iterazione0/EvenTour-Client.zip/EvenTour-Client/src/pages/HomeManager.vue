<template>
  <div>
    <ListTicketManager :auth="authManager" :idAccount="idAccount" />
  </div>
</template>

<script>
import ListTicketManager from "../components/ListEventsManager.vue";

export default {
  name: "HomeManager",

  components: {
    ListTicketManager,
  },
  props: {
    authManager: Boolean
  },
  data: () => ({
    page: "0",
    size: "20",
    param: "",
    order: "",
    idAccount: String
  }),
  created() {
    if (this.getCookie("typeAccount") == "TicketInsp") {
      this.$router.replace({ name: "ScanCode" });
    } else if(this.getCookie("typeAccount") == "User"){
      this.$router.replace({ name: "Home"})
    } else if(this.getCookie("typeAccount") == (undefined || null || "" || "NONE")){
      this.$router.replace({ name: "Home"})
    } else{
      this.idAccount = this.getCookie("idAccount");
    }
  },
  mounted() {
    if (this.getCookie("typeAccount") == "TicketInsp") {
      this.$router.replace({ name: "ScanCode" });
    } else if(this.getCookie("typeAccount") == "User"){
      this.$router.replace({ name: "Home"})
    } else if(this.getCookie("typeAccount") == (undefined || null || "" || "NONE")){
      this.$router.replace({ name: "Home"})
    } else{
      this.idAccount = this.getCookie("idAccount");
    }
  },
  methods: {
    getCookie(name) {
      var cookieArr = document.cookie.split(";");
      for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1]);
        }
      }
      return null;
    },
    logout() {
      this.$emit("auth", false);
      this.$router.replace({ name: "Home" });
    },
     login() {
      this.$router.replace({ name: "Login",
        query: {
          page: this.page,
          nelem: this.size,
          param: this.param,
          order: this.order
        }
      });
    },
  },
};
</script>
