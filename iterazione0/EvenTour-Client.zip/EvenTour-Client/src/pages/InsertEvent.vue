<template>
        <v-container>
            <v-text-field placeholder="Title" v-model="information.title"
             :rules="[() => !!information.title || 'This field is required']"
             prepend-icon="mdi-format-title"/>
            <v-textarea placeholder="Description" v-model="information.description"
            :rules="[() => !!information.description || 'This field is required']"
            prepend-icon="mdi-subtitles-outline"/>
            <v-menu
                ref="menu"
                v-model="menu"
                :close-on-content-click="false"
                :return-value.sync="information.date"
                transition="scale-transition"
                offset-y
                min-width="auto"
            >
            <template v-slot:activator="{ on, attrs }">
                <v-text-field
                    v-model="information.date"
                    label="Pick date"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                ></v-text-field>
            </template>
            <v-date-picker
                v-model="information.date"
                no-title
                scrollable
                :allowed-dates="allowedDates"
                class="mt-4"
                min="2021-11-01"
                max="2024-01-01"
                
            >
                <v-spacer></v-spacer>
                <v-btn
                    text
                    color="primary"
                    @click="menu = false"
                >
                    Cancel
                </v-btn>
                <v-btn
                    text
                    color="primary"  
                    @click="$refs.menu.save(information.date)"
                >
                     OK
                </v-btn>
            </v-date-picker>
            </v-menu>
            <v-text-field placeholder="Time" type="time" 
            v-model="information.time"
            prepend-icon="mdi-clock-outline"/>
            <v-text-field placeholder="Location" v-model="information.location" 
            prepend-icon="mdi-map-marker"/>
            <v-text-field placeholder="UrlImage" type="url" v-model="information.urlimage" 
            prepend-icon="mdi-image"/>
             <v-container fluid>
                <v-select
                    v-model="information.types"
                    :items="typeList"
                    label="Types"
                    multiple
                >
                <template v-slot:prepend-item>
                    <v-list-item
                        ripple
                        @click="toggle"
                    >
                        <v-list-item-action>
                            <v-icon :color="information.types > 0 ? 'indigo darken-4' : ''">
                                {{ icon }}
                            </v-icon>
                        </v-list-item-action>
                        <v-list-item-content>
                            <v-list-item-title>
                                Select All
                            </v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                    <v-divider class="mt-2"></v-divider>
                </template>
                <template v-slot:append-item>
                    <v-divider class="mb-2"></v-divider>
                </template>
                </v-select>
            </v-container>
            <v-text-field placeholder="TotSeat" type="number" step="1" v-model="information.totseat" 
            prepend-icon="mdi-seat-outline"/>
            <v-text-field placeholder="Price" type="number" step="0.1" v-model="information.price"  suffix="€"
            prepend-icon="mdi-currency-usd"/>
            <v-btn v-on:click="homeauth()">Registrati</v-btn>
        </v-container>
</template>

<script>
    export default {
        name:"SignupForm",
        data: () => ({
          information: {
            title: "",
            description: "",
            location: "",
            date: '2021-11-27',
            time:"00:00",
            types:[],
            urlimage: "",
            totseat: "1",
            price: "0"
          },
          menu: false,
          typeList:['Concerto - Musica commerciale - Pop',
                    'Concerto - Musica commerciale - Disco/Dance',
                    'Concerto - Musica commerciale - Altro',
                    'Concerto - Rock - Hard rock',
                    'Concerto - Rock - Metal',
                    'Concerto - Rock - Punk',
                    'Concerto - Rock - Altro',
                    'Concerto - Rap - Trap',
                    'Concerto - Rap - Freestyle',
                    'Concerto - Rap - Battle',
                    'Concerto - Classica - Lirica',
                    'Concerto - Classica - Orchestrale',
                    'Concerto - Classica - Strumentale',
                    'Concerto - Classica - Gospel',
                    'Teatro - Musical',
                    'Teatro - Commedia',
                    'Teatro - Opera lirica',
                    'Teatro - Prosa',
                    'Teatro - Magia/Cabaret',
                    'Teatro - Tragedia',
                    'Teatro - Danza',
                    'Altri eventi - Sfilata',
                    'Altri eventi - Proiezione speciale (non solo al cinema)',
                    'Altri eventi - Evento sportivo',
                    'Altri eventi - Firmacopie/Presentazione',
                    'Altri eventi - Circo']
        }),
        computed:{
            chooseAllTypes () {
                return this.information.types.length === this.typeList.length
            },
            chooseSomeTypes () {
                return this.information.types.length > 0
            },
            icon () {
                if (this.chooseAllTypes) return 'mdi-close-box'
                if (this.chooseSomeTypes) return 'mdi-minus-box'
                return 'mdi-checkbox-blank-outline'
            }
        },
        methods:{
          homeauth(){
            //Check fields
            this.$router.replace({ name: "Home"});
          },
          toggle () {
            this.$nextTick(() => {
                this.typeList = this.information.types.slice()
                
            })
        },
         allowedDates: val => new Date(val)>new Date(),
        }
    }
</script>

<style scoped>
</style>