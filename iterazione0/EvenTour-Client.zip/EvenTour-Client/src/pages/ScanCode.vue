<template>
    <div>
    <v-card v-if="authInsp">
        <v-card-title>Scannerizza Codice</v-card-title>
        <v-card-text>
            <v-text-field placeholder="Insert Code..." v-model="code"></v-text-field>
        </v-card-text>
        <v-card-actions>
            <v-btn v-on:click="checkCode(); overlay = !overlay"> 
                <v-icon>mdi-tick-circle-outline</v-icon>
                Check
            </v-btn>
        </v-card-actions>
    </v-card>
    <v-overlay :color="colorBack" :value="overlay">
      <h1>{{textConfirm}}</h1>
    </v-overlay>
    <v-card v-if="!authInsp"> 
        <v-card-title>Nessuna autorizzazione.</v-card-title>
        <v-btn v-on:click="backHome()">HOME</v-btn>
    </v-card>
    </div>
    
</template>

<script>
//ticket Insp code: TI-3696-7017  (id: 61a0b05abce0e98fbb2dad3c)
//ticket insp password: cetixiye
//booking ok: 61a1f03a7422fb1dcd5ddc95
//booking no (no code booking ok): 61a0a933bce0e98fbb2d999d
//booking no (no event correct): 61a208dd7422fb1dcd5ddcb0
import EvenTourDataService from '../services/EvenTourDataService';
export default {
    name: "ScanCode",
    data: () => ({
        code: "",
        textConfirm: "",
        idEventTmp: "",
        overlay: false,
        colorBack:"white"
    }),
    props: {
        authInsp: Boolean,
        idAccount: String
    },
    watch: {
      overlay (val) {
        val && setTimeout(() => {
          this.overlay = false
        }, 3000)
        this.textConfirm="";
        this.colorBack="white";
      },
    },
    methods: {
        logout() {
            this.$emit("authInsp", false);
            this.$router.replace({ name: "Home" });
        },
        backHome(){
            this.$router.replace({name: "Home"});
        },
        checker(){
            EvenTourDataService.getCheckCode({
                bookingNr: this.code,
                eventId: this.idEventTmp
            }).then((response) => {
                console.log(response.data);
                if(response.data=="ACCESS GRANTED"){
                    this.colorBack="green";
                }else{
                    this.colorBack="red";
                }
               this.textConfirm=response.data;
               this.code="";
            })
        },
        checkCode(){
            if(this.idEventTmp==""){
                EvenTourDataService.getTicket(this.idAccount)
                                            .then((response) => {
                                                this.idEventTmp=response.data.eventId;
                                                this.checker();
                                            })
            }else{
                this.checker()
            }
            
        }
    }
}
</script>

<style>

</style>