<template>
  <v-app>
    <v-app-bar app color="primary" dark>
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
          transition="scale-transition"
          width="40"
        />

        <v-img
          alt="Vuetify Name"
          class="shrink mt-1 hidden-sm-and-down"
          contain
          min-width="100"
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-name-dark.png"
          width="100"
        />
      </div>
      <v-spacer></v-spacer>
      <v-btn v-if="!auth&&!authInsp&&!authManager" v-on:click="login()" text>
        <span class="mr-2">Login</span>
        <v-icon>mdi-account</v-icon>
      </v-btn>
      <v-btn v-if="auth||authManager||authInsp" v-on:click="logout()" text>
        <span class="mr-2">Logout</span>
        <v-icon>mdi-close-circle-outline</v-icon>
      </v-btn>
    </v-app-bar>
    <v-main>
      <router-view
        @auth="setAuth"
        :auth="auth"
        @authInsp="setAuthInsp"
        :authInsp="authInsp"
        @authManager="setAuthManager"
        :authManager="authManager"
        @infoAccount="setInfoAccount"
        :typeAccount="typeAccount"
        :idAccount="idAccount"
      />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "App",
  data: () => ({
    //Manteniamo la connessione?
    idAccount: "",
    typeAccount: "",
    auth: Boolean,
    authInsp: Boolean,
    authManager: Boolean,
  }),
  created() {
    this.falseAuth();
        this.idAccount = this.getCookie("idAccount");
        this.typeAccount = this.getCookie("typeAccount");
        if (
          this.idAccount != null &&
          this.typeAccount != null
        ) {
          if (this.typeAccount === "User") {
            this.setAuth(true);
          } else if (this.typeAccount === "TicketInsp") {
            this.setAuthInsp(true);
          } else if (this.typeAccount === "Manager") {
            this.setAuthManager(true);
          }
        }
      },
  mounted() {
    this.falseAuth();
    this.idAccount = this.getCookie("idAccount");
    this.typeAccount = this.getCookie("typeAccount");
    if (
      this.idAccount != null &&
      this.typeAccount != null
    ) {
      if (this.typeAccount === "User") {
        this.setAuth(true);
      } else if (this.typeAccount === "TicketInsp") {
        this.setAuthInsp(true);
      } else if (this.typeAccount === "Manager") {
        this.setAuthManager(true);
      }
    }
  },
  methods: {
    getCookie(name) {
      var cookieArr = document.cookie.split(";");
      for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1]);
        }
      }
      return null;
    },
    falseAuth() {
      this.auth = false;
      this.authInsp = false;
      this.authManager = false;
    },
    setAuth(status) {
      this.falseAuth();
      this.auth = status;
    },
    setAuthInsp(status) {
      this.falseAuth();
      this.authInsp = status;
    },
    setAuthManager(status) {
      this.falseAuth();
      this.authManager = status;
    },
    setInfoAccount(idAcc, type) {
      this.idAccount = idAcc;
      document.cookie = "idAccount=" + encodeURIComponent(idAcc) + ";secure; path='/'; max-age=3600";
      this.typeAccount = type;
      document.cookie = "typeAccount=" + encodeURIComponent(type) + ";secure; path='/'; max-age=3600";
    },
    logout() {
      this.falseAuth();
      this.setInfoAccount("","");
      this.$router.replace({name: "Home"});
    },
     login() {
      this.$router.replace({ name: "Login",
        query: {
          page: this.page,
          nelem: this.size,
          param: this.param,
          order: this.order
        }
      });
    },
  },
};
</script>
