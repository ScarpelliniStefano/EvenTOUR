<template>
    <div id="bookevent-form">
        <v-container>
            
        </v-container>
    </div>
</template>

<script>
    export default {
        name:"BookEvent",
        date: () => ({

        })
    }
</script>

<style scoped>
</style>