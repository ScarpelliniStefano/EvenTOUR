<template>
        <v-container>
            <v-text-field placeholder="Name" v-model="information.name"/>
            <v-text-field placeholder="Surname" v-model="information.surname"/>
            <v-radio-group v-model="information.sex"  >
                <template v-slot:label >
                    <div>Sex</div>
                </template>
                <v-radio value="M">
                    <template v-slot:label>
                        <div>M</div>
                    </template>
                </v-radio>
                <v-radio value="F">
                    <template v-slot:label>
                        <div>F</div>
                    </template>
                </v-radio>
                <v-radio value="*">
                    <template v-slot:label>
                        <div>Other</div>
                    </template>
                </v-radio>
            </v-radio-group>
            <v-date-picker v-model="information.datebirth" ></v-date-picker>
            <v-text-field placeholder="Residence" v-model="information.residence" />
            <v-text-field placeholder="E-mail" v-model="information.mail" />
            <v-text-field placeholder="Password" type="password" v-model="information.password" />
            <v-checkbox>Accetto i termini e le condizioni</v-checkbox>
            <v-btn v-on:click="homeauth()">Registrati</v-btn>
        </v-container>
</template>

<script>
    export default {
        name:"SignupForm",
        data: () => ({
          information: {
            name: "",
            surname: "",
            sex: "",
            datebirth: "",
            residence: "",
            mail: "",
            password: ""
          }
        }),
        methods:{
          homeauth(){
            //Check fields
            this.$router.replace({ name: "Home"});
          }
        }
    }
</script>

<style scoped>
</style>