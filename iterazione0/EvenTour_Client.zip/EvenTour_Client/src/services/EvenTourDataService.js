import http from "../http-common";

class EvenTourDataService {
  getAllEvents() {
    return http.get("/events");
  }

  getAllPagedEvents(page,size,param,order) {
    if(param==null){
      if(page==null&&size!==null)
        return http.get(`/events?page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events?page=${page}&size=20`);
      if(page!==null&&size!==null)
        return http.get(`/events?page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events`);
    }else{
      if(page==null&&size!==null)
        return http.get(`/events?ordered=${order}&param=${param}&page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events?ordered=${order}&param=${param}&page=${page}&size=20`);
      if(page!==null&&size!==null)
        return http.get(`/events?ordered=${order}&param=${param}&page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events?ordered=${order}&param=${param}`);
    }
  }

  getAllPagedEventsManager(page,size, id) {
      if(page==null&&size!==null)
        return http.get(`/events/manager/${id}/manager/${id}?page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events/manager/${id}?page=${page}&size=20`);
      if(page!==null&&size!==null)
        return http.get(`/events/manager/${id}?page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events/manager/${id}`);
  }

  getEventManager(id){
    return http.get(`/events/manager/${id}`)
  }

  getEvent(id) {
    return http.get(`/events/${id}`);
  }

  createEvent(data) {
    return http.post("/events", data);
  }

  getLogUser(data){
    return http.post('/account', data);
  }

  getBookingEventOfUser(id, idEv){
    return http.get(`bookings/user/${id}/event/${idEv}`)
  }

  createBooking(data){
    return http.post(`/bookings`, data);
  }

  deleteBooking(id){
    return http.delete(`/bookings/${id}`);
  }
  
  getTicket(id){
    return http.get(`/ticketInsps/${id}`)
  }

  getCheckCode(data) {
    return http.post("/bookings/check", data);
  }

  getTicketInspEvent(idEvent){
    return http.get(`/ticketInsps/event/${idEvent}`);
  }
  

}

export default new EvenTourDataService();