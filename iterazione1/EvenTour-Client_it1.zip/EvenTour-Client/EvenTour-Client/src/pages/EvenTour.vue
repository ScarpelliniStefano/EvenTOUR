<template>
  <div>
    <v-row v-if="startPaymentCard && totPayment > 0" justify="center">
      <v-dialog v-model="startPaymentCard" persistent>
        <!--  MODULO PAGAMENTO CARTA -->
        <div class="wrapper" id="app">
          <CardForm
            :form-data="formData"
            @input-card-number="updateCardNumber"
            @input-card-number-not-mask="updateCardNumberNotMask"
            @input-card-name="updateCardName"
            @input-card-month="updateCardMonth"
            @input-card-year="updateCardYear"
            @input-card-cvv="updateCardCvv"
            @input-card-check="closeDialog"
            @close-payment="startPaymentCard = false"
          />
        </div>
      </v-dialog>
    </v-row>
    <v-timeline align-top :dense="$vuetify.breakpoint.smAndDown">
      <v-timeline-item
        color="yellow"
        v-for="(event, i) in events"
        :key="i"
        fill-dot
      >
        <v-card color="yellow">
          <v-card-title class="text-h6">{{ event.title }}</v-card-title>
          <v-card-subtitle>
            {{ new Date(event.dataOra) }} -
            {{ event.price.toFixed(2) }} €/persona - Posti liberi:
            {{ event.freeSeat }}*
          </v-card-subtitle>
          <v-card-text class="white text--primary">
            {{ event.description }}
          </v-card-text>
        </v-card>
      </v-timeline-item>
    </v-timeline>
    <p>Prezzo totale: {{ totPayment }} €</p>
    <p>
      * Non garantiamo la prenotazione di tutti gli eventi a causa di
      aggiornamenti relativi ad altre prenotazioni derivate da altri utenti.
    </p>
    <v-btn color="indigo" @click="startPaymentCard = true">Prenota</v-btn>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";
import CardForm from "../components/CardForm";

export default {
  name: "EvenTour",
  data() {
    return {
      events: [],
      totPayment: 0,
      startPayment: false,
      startPaymentCard: false,
      confirmPayment: false,
      txtPayment: "Pagamento Effettuato",
      formData: {
        cardName: "",
        cardNumber: "",
        cardNumberNotMask: "",
        cardMonth: "",
        cardYear: "",
        cardCvv: "",
      },
    };
  },
  props: {
    idAccount: String,
    typeAccount: String,
  },
  components: {
    CardForm,
  },
  mounted() {
    this.startPayment = false;
    this.getEvents();
  },
  methods: {
    getEvents() {
      console.log(this.$route.params.id);
      console.log(this.$route.params.numEvents);
      EvenTourDataService.eventour(
        this.$route.params.id,
        this.$route.params.numEvents
      ).then((response) => {
        this.events = response.data;
        this.events.forEach((event) => {
          this.totPayment += event.price;
        });
      });
    },
    bookEvents() {
      var evProcess = 0;
      this.events.forEach((event) => {
        EvenTourDataService.getEvent(event.id).then((response) => {
          if (response.data.freeSeat < 1) {
            alert("Nessun posto disponibile per evento: " + event.title);
          } else {
            EvenTourDataService.createBooking({
              userId: this.idAccount,
              eventId: event.id,
              prenotedSeat: 1,
            });
          }
          evProcess++;
        });
      });
      while (evProcess != this.events.length) {
        console.log("In attesa...");
      }
      this.$router.replace({ name: "Home" });
    },
    updateCardNumber(val) {
      this.formData.cardNumber = val;
    },
    updateCardNumberNotMask(val) {
      this.formData.cardNumberNotMask = val;
    },
    updateCardName(val) {
      this.formData.cardName = val;
    },
    updateCardMonth(val) {
      this.formData.cardMonth = val;
    },
    updateCardYear(val) {
      this.formData.cardYear = val;
    },
    updateCardCvv(val) {
      this.formData.cardCvv = val;
    },
    closeDialog() {
      var dataPay = {
        idUser: this.idAccount,
        cardNr: this.formData.cardNumberNotMask,
        cardName: this.formData.cardName,
        authNr: this.formData.cardCvv,
        date: this.formData.cardMonth + "/" + this.formData.cardYear,
        amount: this.totPayment.toFixed(2),
      };
      EvenTourDataService.payment(dataPay, "user")
        .then((response) => {
          if (response.data.startWith("OK")) {
            alert(response.data.slice(response.data.indexOf("Transaction")));
            this.startPaymentCard = false;
            this.bookEvents();
          } else {
            alert(response.data);
            this.startPaymentCard = true;
          }
        })
        .catch((e) => {
          console.error(e);
        });
      this.startPaymentCard = true;
    },
  },
};
</script>

<style>
</style>