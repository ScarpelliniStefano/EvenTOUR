<template>
  <div id="event-form">
    <v-snackbar v-model="confirmPayment" :timeout="1000">
      {{this.txtPayment}}
      <template v-slot:action="{ attrs }">
        <v-btn color="blue" text v-bind="attrs" @click="confirmPayment = false">
          Ok
        </v-btn>
      </template>
    </v-snackbar>
    <v-row v-if="startPayment" justify="center">
      <v-dialog v-model="startPayment" persistent max-width="300">
        <v-card>
          <v-card-title class="text-h5">
            Pagamento dell'evento: {{this.eventData.title}}
          </v-card-title>
          <v-card-text>Posti da prenotare: <v-spacer></v-spacer>{{this.nPrenotati}}</v-card-text>
          <v-card-text>Totale da pagare: <v-spacer></v-spacer>{{(this.nPrenotati * this.eventData.price).toFixed(2)}}€</v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="green darken-1" text @click="booking()">
              ACCETTA
            </v-btn>
            <v-btn color="red darken-1" text @click="startPayment = false;">
              ANNULLA
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-row>
    <v-row v-if="startPaymentCard && eventData.price>0" justify="center">
      <v-dialog v-model="startPaymentCard" persistent>
        <!--  MODULO PAGAMENTO CARTA-->
        <div class="wrapper" id="app">
        <CardForm
          :form-data="formData"
          @input-card-number="updateCardNumber"
          @input-card-number-not-mask="updateCardNumberNotMask"
          @input-card-name="updateCardName"
          @input-card-month="updateCardMonth"
          @input-card-year="updateCardYear"
          @input-card-cvv="updateCardCvv"
          @input-card-check="closeDialog"
        />
        </div>
      </v-dialog>
    </v-row>
    <v-btn
      style="float: right;"
      tile
      fab
      @click="backHome()"
    >
      <v-icon color="blue">
        mdi-home
      </v-icon>
    </v-btn>
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-card-title>{{ eventData.title }}</v-card-title>
      <v-card-text>
        <div>{{ eventData.description }}</div><br>
        <div>{{ this.eventData.location.locality }}</div>
        <div>{{ this.eventData.location.city }} ({{this.eventData.location.sigla}})</div><br>
        <div>{{ eventData.dataOra }}</div>
        <div>Prezzo: {{ eventData.price }} (x1)</div>
      </v-card-text>
      <v-card-actions>
        <v-btn
          v-if="auth && !this.book && maxPosti > 0"
          @click="startPayment = true"
        >
          PRENOTA
        </v-btn>
        <v-slider
          v-if="maxPosti > 0 && auth && !this.book"
          v-model="nPrenotati"
          color="blue"
          label="Biglietti"
          hint="Numero Prenotati"
          min="1"
          :max="maxPosti"
          thumb-label>
        </v-slider>
        <v-btn
          v-if="!auth"
          @click="login()"
        >
          ACCEDI
        </v-btn>
        <v-btn v-if="this.book & auth">
          <v-icon>mdi-check-bold</v-icon>
        </v-btn>
        <v-spacer></v-spacer>
        <div v-if="this.book & auth">
            Posti prenotati: {{this.numSeat.toString()}}
        </div>
        <v-spacer></v-spacer>
        <v-btn
          color="red darken-3"
          v-if="this.book & auth"
          v-on:click="delBooking()"
        >
          <v-icon color="black">mdi-delete-forever</v-icon>
        </v-btn>
      </v-card-actions>
    </v-card>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";
import CardForm from '../components/CardForm'

export default {
  name: 'EventForm',
  props: {
    auth: Boolean,
    idAccount: String,
    typeAccount: String
    
  },
  components:{
    CardForm
  },
  data: () => ({
    eventData: Object,
    book: Boolean,
    numSeat: Number,
    idEvent: String,
    nPrenotati: 1,
    maxPosti: 8,
    startPayment: false,
    startPaymentCard: false,
    confirmPayment: false,
    txtPayment: 'Pagamento Effettuato',
    formData: {
        cardName: '',
        cardNumber: '',
        cardNumberNotMask: '',
        cardMonth: '',
        cardYear: '',
        cardCvv: ''
      }
  }),
  created () {
    // ADD function that retrieve data of event and booking
    // this.getEvent(this.$route.params.id);
  },
  mounted () {
    this.startPayment = false
    this.getEvent()
    if(this.eventData.freeSeat > 8){
      this.maxPosti = 8
    } else {
      this.maxPosti = this.eventData.freeSeat
    }
  },

  methods: {
    login() {
      this.$router.replace({ name: "Login" });
    },

    booking(){
      if(this.eventData.price==0) this.bookingEvent();
      this.txtPayment = "Pagamento Effettuato"
      this.confirmPayment = false
      this.startPayment = false
      this.startPaymentCard = true
    },
    bookingEvent () {
      // ADD funzione prenotazione
      EvenTourDataService.getEvent(this.idEvent).then((response) => {
        if (response.data.freeSeat < this.nPrenotati)
        {
          alert("Numeri di posti massimi disponibili: " + response.data.freeSeat)
          this.maxPosti = response.data.freeSeat
        } else {
          EvenTourDataService.createBooking({
            userId: this.idAccount,
            eventId: this.idEvent,
            prenotedSeat: this.nPrenotati
          })
          this.book = true
          this.numSeat = this.nPrenotati
        }
      }).catch((err) => {
        this.txtPayment = err
        this.startPayment = false
        this.confirmPayment = false
      })
    },
    backHome() {
      this.$router.replace({ name: "Home" });
    },
    getEvent() {
      this.idEvent = this.$route.params.id;
      EvenTourDataService.getEvent(this.idEvent).then((response) => {
        EvenTourDataService.getBookingEventOfUser(
          this.idAccount,
          this.idEvent
        ).then((responseUserEvent) => {
          if (responseUserEvent.data.length < 1) {
            this.book = false;
          } else {
            this.book = true;
            this.numSeat = responseUserEvent.data[0].prenotedSeat;
          }
        });
        this.eventData = response.data;
        var time=new Date(this.eventData.dataOra);
        var month= time.toLocaleString('default', { month: 'long' });
        this.eventData.dataOra =
          time.getDate() +
          " " +
          (month) +
          " " +
          time.getFullYear() +
          "  h."+
          ("0" + time.getHours().toString()).slice(-2) +
          ":" +
          ("0" + time.getMinutes()).slice(-2);
        if(this.eventData.freeSeat > 8){
          this.maxPosti = 8
        } else {
          this.maxPosti = this.eventData.freeSeat
        }
      });
    },
    delBooking() {
      EvenTourDataService.getBookingEventOfUser(
        this.idAccount,
        this.idEvent
      ).then((responseUserEvent) => {
            EvenTourDataService.deleteBooking(responseUserEvent.data[0].id);
            this.book = false;
            this.numSeat = 0;
      });
    },
    updateCardNumber (val) {
      this.formData.cardNumber=val;
    },
    updateCardNumberNotMask (val) {
      this.formData.cardNumberNotMask=val;
    },
    updateCardName (val) {
      this.formData.cardName=val;
    },
    updateCardMonth (val) {
      this.formData.cardMonth=val;
    },
    updateCardYear (val) {
      this.formData.cardYear=val;
    },
    updateCardCvv (val) {
      this.formData.cardCvv=val;
    },
    closeDialog(){
      var dataPay={
        'idUser': this.idAccount,
        'cardNr':this.formData.cardNumberNotMask,
        'cardName':this.formData.cardName,
        'authNr':this.formData.cardCvv,
        'date':this.formData.cardMonth+"/"+this.formData.cardYear,
        'amount':(this.nPrenotati * this.eventData.price).toFixed(2)
      }
      console.log(dataPay)
      this.bookingEvent();
      EvenTourDataService.payment(dataPay,"user").then((response)=>{
        console.log(response.data)
        if(response.data.includes("OK.")){
          alert(response.data.slice(response.data.indexOf("Transaction")))
          this.startPaymentCard = false;
        }else{
          alert(response.data)
          this.delBooking()
        }
      })
    }
  },
};
</script>

<style scoped>
</style>

<style lang="scss">
@import '../assets/style.scss';
</style>