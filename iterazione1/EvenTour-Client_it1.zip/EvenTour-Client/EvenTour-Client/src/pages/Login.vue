<template>
  <div id="login-form">
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-text-field
        placeholder="Username"
        name="username"
        v-model="input.username"
        :rules="[() => !!input.username || 'This field is required']"
      />
      <v-text-field
        placeholder="Password"
        name="password"
        v-model="input.password"
        :append-icon="showP ? 'mdi-eye' : 'mdi-eye-off'"
        :rules="[rules.required, rules.min]"
        :type="showP ? 'text' : 'password'"
        hint="At least 8 characters"
        counter
        @click:append="showP = !showP"
      />
      <v-row class="text-center" align="center" justify="center">
        <v-col key="login" cols="6" sm="6" md="12" lg="12" xl="12">
          <v-btn v-on:click="login(); overlay = !overlay">LOGIN</v-btn>
        </v-col>
        <v-col key="signup" cols="6" sm="6" md="6" lg="6" xl="6">
          <v-btn v-on:click="signup()">SIGNUP</v-btn>
        </v-col>
        <v-col key="signupmanager" cols="6" sm="6" md="6" lg="6" xl="6">
          <v-btn v-on:click="signupManager()">SIGNUP MANAGER</v-btn>
        </v-col>
      </v-row>
    </v-card>
     <v-overlay :color="colorBack" :value="overlay">
      <h1>{{textErrorLogin}}</h1>
    </v-overlay>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService.js";
import md5 from "js-md5";
export default {
  name: "Login",
  data: () => ({
    input: {
      username: "",
      password: "",
    },
    showP: false,
    overlay : false,
    colorBack:"white",
    textErrorLogin:"",
    rules: {
          required: value => !!value || 'Required.',
          min: v => v.length >= 8 || 'Min 8 characters'
    }
  }),
  props: ["auth", "authIsp", "authManager"],
  watch: {
      overlay (val) {
        val && setTimeout(() => {
          this.overlay = false
        }, 3000)
      },
    },
  methods: {
    login() {
      if (this.input.username != "" && this.input.password != "") {
        EvenTourDataService.getLogUser({
          user: this.input.username,
          password: md5(this.input.password),
        })
          .then((response) => {
            console.log(response);
            if (response.data.typeUser != "NONE") {
              this.colorBack="white"
              this.$emit(
                "infoaccount",
                response.data.user.id,
                response.data.typeUser,
                7
              );
              if (response.data.typeUser == "User") {
                this.$emit("auth", true);
                var n = this.$route.query.nelem;
                var param = this.$route.query.param;
                var order = this.$route.query.order;
                var p = this.$route.query.page;

                if (param != undefined) {
                  this.$router.replace({
                    name: "Home",
                    params: { npage: p },
                    query: {
                      nelem: n,
                      param: param,
                      order: order != undefined ? "asc" : order,
                    },
                  });
                } else {
                  this.$router.replace({
                    name: "HomePage",
                    params: { npage: p },
                    query: {
                      nelem: n,
                    },
                  });
                }
              }
              if (response.data.typeUser == "TicketInsp") {
                this.$emit("authinsp", true);
                this.$router.replace({ name: "ScanCode" });
              }
              if (response.data.typeUser == "Manager") {
                this.$emit("authmanager", true);
                this.$router.replace({ name: "HomeManager" })
                //ADD Metodo replace per caricare interfaccia manager
              }
            }else{
              this.colorBack="red"
              this.textErrorLogin=response.data.user;//login errato
            }
          })
          .catch((e) => {
            console.log(e);
          });


      }
    },
    signup() {
      this.$router.replace({ name: "Signup" });
    },
    signupManager() {
      this.$router.replace({ name: "SignupMan" });
    },
  },
};
</script>

<style scoped>
#login-form {
  height: auto;
  width: auto;
}
#card {
  margin: 0;
  top: 100px;
  bottom: 100px;
  height: auto;
}
</style>