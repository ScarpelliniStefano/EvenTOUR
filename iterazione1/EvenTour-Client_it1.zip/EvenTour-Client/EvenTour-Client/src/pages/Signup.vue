<template>
        <v-container fluid>
            <v-text-field placeholder="Name" v-model="information.name"/>
            <v-text-field placeholder="Surname" v-model="information.surname"/>
            <v-text-field placeholder="Username" v-model="information.username"/>
            <v-radio-group v-model="information.sex">
                <template v-slot:label >
                    <div>Sex</div>
                </template>
                <v-radio value="M">
                    <template v-slot:label>
                        <div>M</div>
                    </template>
                </v-radio>
                <v-radio value="F">
                    <template v-slot:label>
                        <div>F</div>
                    </template>
                </v-radio>
            </v-radio-group>
            <v-date-picker v-model="information.dateOfBirth" ></v-date-picker>
            <v-text-field placeholder="E-mail" v-model="information.mail" />
            <v-text-field placeholder="Password" type="password" v-model="information.password" />
            <v-checkbox>Accetto i termini e le condizioni</v-checkbox>
            <v-btn v-on:click="homeauth()">Registrati</v-btn>
        </v-container>
</template>

<script>
    export default {
        name:"SignupForm",
        data: () => ({
          information: {
            name: "",
            surname: "",
            username: '',
            sex: "",
            dateOfBirth: "",
            residence:{
                locality: '',
                city: '',
                cap: '',
                provincia: '',
                sigla: '',
                regione: '',
                lat: 0.000000000,
                lng: 0.000000000
            },
            types: [],
            mail: "",
            password: ""
          }
        }),
        methods:{
          homeauth(){
            //Check fields
            this.$router.replace({ name: "Home"});
          }
        }
    }
</script>

<style scoped>
</style>