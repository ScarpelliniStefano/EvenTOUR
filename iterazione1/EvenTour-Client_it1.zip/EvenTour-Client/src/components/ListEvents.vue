<template>
  <div class="main">
    <v-container fluid>
      <v-row align="center">
        <v-col class="d-flex" cols="12" sm="3">
          <v-text-field
            v-model="page"
            label="Page"
            hide-details
            single-line
            min="1"
            type="number"
          ></v-text-field>
        </v-col>

        <v-col class="d-flex" cols="12" sm="3">
          <v-text-field
            v-model="size"
            hide-details
            single-line
            type="number"
          ></v-text-field>
        </v-col>

        <v-col class="d-flex" cols="12" sm="3">
          <v-select
            hide-details="true"
            :items="items_order"
            v-model="order"
            label="ORDER"
          ></v-select>
        </v-col>
        <v-col cols="12" sm="3">
          <v-btn width="100%" @click="sendMsg()" depressed color="primary"
            >Cerca</v-btn
          >
        </v-col>
      </v-row>
      <v-row align="center" v-if="auth">
        
       <v-col cols="12" sm="3">
           <v-dialog
              v-model="info.dialogData"
              max-width="600px"
            >
          <template v-slot:activator="{ on, attrs }">
              <v-btn
                color="primary"
                dark
                v-bind="attrs"
                v-on="on"
              >
                Date o intervallo di date
              </v-btn>
            </template>
            <v-card>
              <v-card-title>
                <span class="text-h5">Date o intervallo di date</span>
              </v-card-title>
              <v-card-text>
                <v-container>
                  <v-row>
                    <v-col
                      cols="12"
                      sm="6"
                      md="4"
                    >
                      <v-text-field
                        label="Data minima"
                        required
                        type="date"
                        v-model="info.dataGT"
                      ></v-text-field>
                    </v-col>
                    <v-col
                      cols="12"
                      sm="6"
                      md="4"
                    >
                      <v-text-field
                        label="Data massima"
                        required
                        type="date"
                        v-model="info.dataLT"
                      ></v-text-field>
                    </v-col>
                  </v-row>
                </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="info.dialogData = false"
                >
                  Close
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="sendMsgData(); info.dialogData = false"
                >
                  Save
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-col>
        <v-col cols="12" sm="3">
          <v-dialog
              v-model="info.dialogLoc"
              max-width="600px"
            >
          <template v-slot:activator="{ on, attrs }">
              <v-btn
                color="primary"
                dark
                v-bind="attrs"
                v-on="on"
              >
                Località
              </v-btn>
            </template>
            <v-card>
              <v-card-title>
                <span class="text-h5">località</span>
              </v-card-title>
              <v-card-text>
                <v-select
                  :items="this.info.jsonReg"                                                                          
                  label="Regione"
                  v-model="info.selectedReg"
                  @change="getProv()"
                ></v-select>
                
                <v-select v-if="this.info.jsonProv!=null"
                  :items="this.info.jsonProv"
                  label="Provincia"
                  item-text="nome"
                  v-model="info.selectedProv"
                  @change="getCom()"
                ></v-select>
                
                <v-select v-if="this.info.jsonCom!=null"
                  :items="this.info.jsonCom"
                  v-model="info.selectedCom"
                   item-text="nome"
                  label="Comune"
                ></v-select>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="info.dialogLoc = false"
                >
                  Close
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="sendMsgLoc(); info.dialogLoc = false"
                >
                  Save
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-col>
        <v-col cols="12" sm="3">
          <v-dialog
              v-model="info.dialogType"
              max-width="600px"
            >
          <template v-slot:activator="{ on, attrs }">
              <v-btn
                color="primary"
                dark
                v-bind="attrs"
                v-on="on"
              >
                Tipi di evento
              </v-btn>
            </template>
            <v-card>
              <v-card-title>
                <span class="text-h5">Tipi di evento</span>
              </v-card-title>
              <v-card-text>
                <v-container fluid>
                <v-select
                    v-model="info.types"
                    :items="this.info.typeList"
                    label="Types"
                    multiple
                >
                </v-select>
            </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="info.dialogType = false"
                >
                  Close
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="sendMsgType(); info.dialogType = false"
                >
                  Save
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-col>
        <v-col cols="12" sm="3">
              <v-btn
                color="primary"
                dark
                @click="sendMsgPref();"
              >
                Preferenze
              </v-btn>
        </v-col>
      </v-row>
    </v-container>
    <v-container fluid>
      <v-row align="center">
        <v-col
          v-for="card in events"
          :key="card.id"
          :value="card.id.toString()"
          :cols="12"
          :sm="6"
          :md="4"
          :lg="3"
          :xl="2"
        >
          <div>
            <v-card
              id="container"
              max-width="600px"
              max-height="600px"
              min-height="300px"
              min-width="280px"
            >
              <v-img
                align="center"
                :src="card.urlImage"
                max-height="200px"
                max-width="600px"
              />
              <v-card-title>
                    {{ card.title }}
                  </v-card-title>
                  <v-card-subtitle>
                    {{ card.location.locality }}
                    <br />
                    {{ card.location.city + " (" + card.location.sigla + ")" }}
                    <br />
                    {{
                      new Date(card.dataOra).getDate() +
                      "/" +
                      (new Date(card.dataOra).getMonth()+1) +
                      "/" +
                      new Date(card.dataOra).getFullYear() +
                      " h." +
                      ('0' + new Date(card.dataOra).getHours()).slice(-2)+
                      ":" +
                      ('0' + new Date(card.dataOra).getMinutes()).slice(-2)
                    }}
                  </v-card-subtitle>
              <v-card-actions>
                <div>
                  
                </div>
                <v-spacer></v-spacer>
                <v-btn icon v-on:click="goToEvent(card.id.toString())">
                  <v-icon>mdi-information-outline</v-icon>
                </v-btn>
              </v-card-actions>
            </v-card>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService.js";
import axios from 'axios';
//import typesE from "../store/typesE.js";
var typesE = [
    {value:"1.1.1", text:"Concerto - Musica commerciale - Pop"},
    {value:"1.1.2", text:"Concerto - Musica commerciale - Disco/Dance"},
    {value:"1.1.3", text:"Concerto - Musica commerciale - Altro"},
    {value:"1.2.1", text:"Concerto - Rock - Hard rock"},
    {value:"1.2.2", text:"Concerto - Rock - Metal"},
    {value:"1.2.3", text:"Concerto - Rock - Punk"},
    {value:"1.2.4", text:"Concerto - Rock - Altro"},
    {value:"1.3.1", text:"Concerto - Rap - Trap"},
    {value:"1.3.2", text:"Concerto - Rap - Freestyle"},
    {value:"1.3.3", text:"Concerto - Rap - Battle"},
    {value:"1.4.1", text:"Concerto - Classica - Lirica"},
    {value:"1.4.2", text:"Concerto - Classica - Orchestrale"},
    {value:"1.4.3", text:"Concerto - Classica - Strumentale"},
    {value:"1.4.4", text:"Concerto - Classica - Gospel"},
    {value:"2.1", text:"Teatro - Musical"},
    {value:"2.2", text:"Teatro - Commedia"},
    {value:"2.3", text:"Teatro - Opera lirica"},
    {value:"2.4", text:"Teatro - Prosa"},
    {value:"2.5", text:"Teatro - Magia/Cabaret"},
    {value:"2.6", text:"Teatro - Tragedia"},
    {value:"2.7", text:"Teatro - Danza"},
    {value:"3.1", text:"Altri eventi - Sfilata"},
    {value:"3.2", text:"Altri eventi - Proiezione speciale (non solo al cinema)"},
    {value:"3.3", text:"Altri eventi - Evento sportivo"},
    {value:"3.4", text:"Altri eventi - Firmacopie/Presentazione"},
    {value:"3.5", text:"Altri eventi - Circo"}
];


export default {
  name: "Main",
  props: {
    auth: Boolean,
    idAccount: String
  },
  data: () => ({
    events: [],
    items_order: ["asc", "desc", ""],
    page: "1",
    size: "20",
    order: "",
    dataS:"",
    typeS:"",
    locS:"",
    info:{
      dialogData: false,
      dialogLoc: false,
      dialogType: false,
      dataGT:'',
      dataLT:'',
      types:[],
      typeList: typesE,
      selectedReg:'',
      selectedProv:'',
      selectedCom:'',
      jsonReg:null,
      jsonProv:null,
      jsonCom:null
    }
  }),
  methods: {
    getProv(){
      console.log(this.info.selectedReg)
      axios
      .get('https://comuni-ita.herokuapp.com/api/province/'+this.info.selectedReg)
      .then(response => {
        
        this.info.jsonProv=response.data
        console.log(this.info.jsonProv)
      })
    },
    getCom(){
      axios
      .get('https://comuni-ita.herokuapp.com/api/comuni/provincia/'+this.info.selectedProv)
      .then(response => (this.info.jsonCom=response.data))
    },
    goToEvent(id){
      this.$router.replace("/events/" + id);
    },
    sendMsgData(){
        this.$router.replace({
          name: 'HomePage',
          params: {npage: this.page},
          query: {
            nelem: this.size,
            dataI: this.info.dataGT+","+this.info.dataLT
          }
        });
        location.reload();
    },
    sendMsgLoc(){
      console.log(this.info.selectedReg)
      console.log(this.info.selectedProv)
      console.log(this.info.selectedCom)
      if(this.info.selectedProv==''){
        this.locS='regione,'+this.info.selectedReg
      }else if(this.info.selectedCom==''){
        this.locS='provincia,'+this.info.selectedProv
      }else{
        this.locS='city,'+this.info.selectedCom
      }
      console.log(this.locS)
        this.$router.replace({
          name: 'HomePage',
          params: {npage: this.page},
          query: {
            nelem: this.size,
            locEvent: this.locS
          }
        });
        location.reload();
    },
    sendMsgType(){
      console.log(this.info.types)
      this.typeS=this.info.types.join(',')
      console.log(this.typeS)
        this.$router.replace({
          name: 'HomePage',
          params: {npage: this.page},
          query: {
            nelem: this.size,
            typeEvent: this.typeS
          }
        });
        location.reload();
    },
    sendMsgPref(){
      console.log(this.idAccount)
        this.$router.replace({
          name: 'HomePage',
          params: {npage: this.page},
          query: {
            nelem: this.size,
            pref: "true"
          }
        });
        location.reload();
    },
    sendMsg() {
      this.order == "" ? null : this.order
      //let url = "/p/" + this.page + "?nelem=" + this.size + (this.param == "" ? "" : "&param=" + this.param) + (this.order == "" ? "" : "&order=" + this.order);
        if(!this.order){
          this.order = "asc";
        }
        this.$router.replace({
          name: 'HomePage',
          params: {npage: this.page},
          query: {
            nelem: this.size,
            order: this.order
          }
        });
       
        
        location.reload();
      /*this.retrieveE;vents(
        this.page,
        this.size,
        this.param == "" ? null : this.param,
        this.order == "" ? null : this.order
      );*/
    },
    retrieveEventData(p,s,dataI){
      console.log(dataI);
      EvenTourDataService.getAllPagedDataEvents(p, s, dataI)
        .then((response) => {
          console.log(response.data);
          this.events = response.data.events;
        })
        .catch((e) => {
          console.log(e);
        });
    },
    retrieveEventType(p,s,typeStr){
      console.log(typeStr);
      EvenTourDataService.getAllPagedTypeEvents(p, s, typeStr)
        .then((response) => {
          console.log(response.data);
          this.events = response.data.events;
        })
        .catch((e) => {
          console.log(e);
        });
    },

    retrieveEventLoc(p,s,locStr){
      console.log(locStr);
      let locTypeS=locStr.split(',')[0]
      let locS=locStr.split(',')[1]
      EvenTourDataService.getAllPagedLocEvents(p, s, locTypeS,locS)
        .then((response) => {
          console.log(response.data);
          this.events = response.data.events;
        })
        .catch((e) => {
          console.log(e);
        });
    },

     retrieveEventPref(p,s){
      console.log(this.idAccount);
      EvenTourDataService.getAllPagedPrefEvents(p, s, this.idAccount)
        .then((response) => {
          console.log(response.data);
          this.events = response.data.events;
        })
        .catch((e) => {
          console.log(e);
        });
    },
    retrieveEvents(p, s, ord) {
      EvenTourDataService.getAllPagedEvents(p, s, ord)
        .then((response) => {
          console.log(response.data);
          this.events = response.data.events;
        })
        .catch((e) => {
          console.log(e);
        });
    },
    toggle () {
            this.$nextTick(() => {
                this.info.typeList = this.info.types.slice()
                
            })
    }
  },
  computed:{
            chooseAllTypes () {
                return this.info.types.length === this.info.typeList.length
            },
            chooseSomeTypes () {
                return this.info.types.length > 0
            },
            icon () {
                if (this.chooseAllTypes) return 'mdi-close-box'
                if (this.chooseSomeTypes) return 'mdi-minus-box'
                return 'mdi-checkbox-blank-outline'
            }
  },
  created() {
    var n = this.$route.query.nelem;
    var order = this.$route.query.order;
    var p = this.$route.params.npage;
    var dataInterval = this.$route.query.dataI;
    var typeInterval = this.$route.query.typeEvent;
    var locInterval = this.$route.query.locEvent;
    var prefInterval = this.$route.query.pref;
    this.page = p<1 || p==undefined ? 1 : p;
    this.size = n<16 || n==undefined ? 16 : n;
    this.order = order == ("" || undefined) ? "asc" : order;
    this.dataS = dataInterval == ("" || undefined) ? "" : dataInterval;
    this.typeS = typeInterval == ("" || undefined) ? "" : typeInterval;
    this.locS = locInterval == ("" || undefined) ? "" : locInterval;
    this.pref = prefInterval == ("" || undefined) ? "" : prefInterval;
    if(this.dataS!=""){
      console.log("if")
      this.retrieveEventData(this.page-1,this.size,this.dataS);
    }else if(this.typeS!=""){
      console.log("if2")
      this.retrieveEventType(this.page-1,this.size,this.typeS);
    }else if(this.locS!=""){
      console.log("if3")
      this.retrieveEventLoc(this.page-1,this.size,this.locS);
    }else if(this.pref!=""){
      console.log("if4")
      this.retrieveEventPref(this.page-1,this.size);
    }else{
      console.log("else")
      console.log(this.page+" "+this.size+" "+this.order)
      this.retrieveEvents(this.page-1, this.size, this.order);
    }
  },
  mounted() {
      var url="https://comuni-ita.herokuapp.com/api/regioni";
      axios.get(url).then(response => {
        //console.log(response.data);
        //const jsonData=;
       // console.log(jsonData);
        this.info.jsonReg=response.data;
        });
      
    /*var n = this.$route.query.nelem;
    var param = this.$route.query.param;
    var order = this.$route.query.order;
    var p = this.$route.params.npage;
    this.retrieveEvents(p<=0 || p==undefined ? 0 : p-1, n==undefined ? null : n, param==""||undefined ? null : param, order==""||undefined ? "asc" : order);
  */
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
