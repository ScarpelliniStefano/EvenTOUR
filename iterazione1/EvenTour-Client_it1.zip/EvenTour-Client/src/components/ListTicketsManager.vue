<template>
  <div class="main">
    <v-container fluid class="blue lighten-5">
      <h4>Lista Ticket Inspector</h4>
      <div style="height: 10px"></div>
      <v-list>
        <v-list-item v-for="elem in tickets" :key="elem.id">
          <v-list-item-content>
            <v-list-item-title v-text="elem.fullName"></v-list-item-title>
            <v-list-item-content v-text="'Code: '+elem.code + ' - Password: ' + elem.password"></v-list-item-content>
            <v-list-item-action>
                <v-btn
                  icon
                  color="red"
                  @click="deleteTicket(elem.id.toString())">
                    <v-icon>mdi-delete-forever-outline</v-icon>
                </v-btn>
            </v-list-item-action>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-container>
    <v-row align="center" justify="space-around">
      <v-dialog
      v-model="dialog"
      persistent
      max-width="600px"
    >
      <template v-slot:activator="{ on, attrs }">
        <v-btn
              tile
              color="success"
              v-bind="attrs"
              v-on="on"> 
        <v-icon left>
        mdi-pencil
        </v-icon>
        Inserisci ticket Inspector
      </v-btn>
      </template>
      <v-card>
        <v-card-title>
          <span class="text-h5">Ticket inspector</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-row>
              <v-col
                cols="12"
                sm="6"
                md="4"
              >
                <v-text-field
                  label="first name *"
                  required
                  v-model="firstName"
                ></v-text-field>
              </v-col>
              <v-col
                cols="12"
                sm="6"
                md="4"
              >
                <v-text-field
                  label="Last name"
                  v-model="lastName"
                ></v-text-field>
              </v-col>
            </v-row>
          </v-container>
          <small>*indicates required field</small>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="blue darken-1"
            text
            @click="dialog = false"
          >
            Close
          </v-btn>
          <v-btn
            color="blue darken-1"
            text
            @click="addTicket();"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    </v-row>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService.js";

export default {
  name: "ListTicketManager",
  props: {
    idAccount: String,
    idEvent: String,
  },
  data: () => ({
    tickets: [],
    dialog: false,
    firstName:"",
    lastName:""
  }),
  methods: {
    retrieveTicketInsp() {
      EvenTourDataService.getTicketInspEvent(this.idEvent)
        .then((response) => {
          console.log(response.data);
          this.tickets = response.data;
        })
        .catch((e) => {
          console.log(e);
        });
    },
    deleteTicket(idTicket){
      EvenTourDataService.deleteTicket(idTicket).then(() => {
        this.retrieveTicketInsp();
      }).catch((err) => {
        console.log(err);
      });
    },
    addTicket(){
      if(this.firstName!== ""){
        let nameFull=this.firstName;
        if(this.lastName!=""){
          nameFull+=" "+this.lastName
        }
        EvenTourDataService.createTicket(this.idEvent,nameFull)
              .then((response) => {
                console.log("risposta: ")
                console.log(response)
                if(response.status==200) this.retrieveTicketInsp();
                else console.log(response.status)
              }).catch(console.log);
              this.dialog=false;
      }
      else{
            alert("ricontrolla i dati");
      }
    }
  },
  created() {
    this.retrieveTicketInsp();
  },
  mounted() {},
};
</script>
