<template>
  <div>
    <ListEventsBooked
      :auth="auth"
      :idAccount="idAccount"
    />
  </div>
</template>

<script>
import ListEventsBooked from '../components/ListEventsBooked.vue'

export default {
  name: 'EventsBookUser',

  components: {
    ListEventsBooked
  },
  props: {
    auth: Boolean,
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == (undefined || null || '' || 'NONE')) {
      this.$router.replace({ name: 'Home' })
    }
  },
  mounted () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == (undefined || null || '' || 'NONE')) {
      this.$router.replace({ name: 'Home' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    logout () {
      this.$emit('auth', false)
      this.$router.replace({ name: 'Home' })
    },
    login () {
      this.$router.replace({
        name: 'Login'
      })
    }
  }
}
</script>
