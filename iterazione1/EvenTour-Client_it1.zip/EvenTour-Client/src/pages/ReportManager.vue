<template>
  <v-card>
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Ricerca"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="repoElem"
      :search="search"
    ></v-data-table>
    <v-card>
    <v-sparkline
        :labels="balanceElem"
        :value="balanceElem"
        color="green"
        line-width="2"
        smooth>
    </v-sparkline>
    </v-card>
  </v-card>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";
export default {
    data: () => ({
        search: '',
        headers: [
        {
            text: 'Evento',
            align: 'start',
            filterable: false,
            value: 'title',
        },
        { text: 'Data Evento', value: 'eventDetails.dataOra' },
        { text: 'Nr. Prenotazioni', value: 'occupedSeat' },
        { text: 'Nr. Effettivo', value: 'comedPeople' },
        { text: 'Saldo', value: 'balance' },
        { text: 'Perdita', value: 'lost' },
        ],
        repoElem: [],
        balanceElem: [],
        labelElem: []
    }),
    props: {
        idAccount: String,
        typeAccount: String
    },
    created(){
        if(this.typeAccount === "NONE" || ""){
            this.$router.replace({name: "Home"});
        } else if (this.typeAccount === "User"){
            this.$router.replace({name: "Home"})
        } else if (this.typeAccount === "TicketInsp"){
            this.$router.replace({name: "ScanCode"})
        /*} else if (this.typeAccount === "Manager") {
            console.log("Funzione da implementare")*/
        } else {
            this.$router.replace({name: "Home"})
        }
    },
    mounted(){
        EvenTourDataService.reportManager(this.idAccount).then(response => {
            this.repoElem = response.data
            this.repoElem.forEach(element => {
                this.balanceElem.push(element.balance)
            });
        })
    }
}
</script>

<style>

</style>