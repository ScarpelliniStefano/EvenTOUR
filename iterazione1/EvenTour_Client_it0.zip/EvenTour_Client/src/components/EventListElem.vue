<template>
    <v-card id="container" width="320px" height="320px">
        <v-img :src=imgURL height="180px" width="320px">
        </v-img>
        
        <v-card-actions>
            <div>
                <v-card-title>
                    {{ title }}
                </v-card-title>
                <v-card-subtitle>
                    {{ location }} - {{ time }}
                </v-card-subtitle>
            </div>
            <v-spacer></v-spacer>
            <v-btn icon>
                <v-icon>mdi-plus-circle-outline</v-icon>
            </v-btn>
        </v-card-actions>
    </v-card>
</template>

<script>
export default {
    name: 'StartEventComponent',
    props: {
        imgURL: String,
        title: String,
        location: String,
        time: String
    }
}
</script>

<style scoped>

</style>