<template>
    <div id="signup-form">
        <v-container fluid>
            <v-text-field placeholder="Title" />
            <v-text-field placeholder="Description" />

            <v-date-picker></v-date-picker>
            <v-text-field placeholder="Residence" />
            <v-text-field placeholder="E-mail" />
            <v-text-field placeholder="Password" type="password" />
        </v-container>
    </div>
</template>

<script>
    export default {
        name:"InsertEvent",
        date: () => ({

        })
    }
</script>

<style scoped>
</style>