<template>
  <div class="main">
    <v-container fluid class="blue lighten-5">
      <h4>Lista Ticket Inspector</h4>
      <div style="height: 10px"></div>
      <v-list>
        <v-list-item v-for="elem in tickets" :key="elem.id">
          <v-list-item-content>
            <v-list-item-title v-text="elem.fullName"></v-list-item-title>
          </v-list-item-content>
          <v-list-item-icon>
            <v-icon color="red accent-4">
              mdi-delete-forever-outline
            </v-icon>
          </v-list-item-icon>
        </v-list-item>
      </v-list>
    </v-container>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService.js";

export default {
  name: "ListTicketManager",
  props: {
    idAccount: String,
    idEvent: String,
  },
  data: () => ({
    tickets: [],
  }),
  methods: {
    retrieveTicketInsp() {
      EvenTourDataService.getTicketInspEvent(this.idEvent)
        .then((response) => {
          console.log(response.data);
          this.tickets = response.data;
        })
        .catch((e) => {
          console.log(e);
        });
    },
  },
  created() {
    this.retrieveTicketInsp();
  },
  mounted() {},
};
</script>
