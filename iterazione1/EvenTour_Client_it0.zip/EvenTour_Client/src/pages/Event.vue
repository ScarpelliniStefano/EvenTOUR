<template>
  <div id="event-form">
    <v-btn style="float: right;" tile fab v-on:click="backHome()"> 
        <v-icon color="blue">mdi-home</v-icon>     
    </v-btn>
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-card-title>{{ eventData.title }}</v-card-title>
      <v-card-text>
        <div>{{ eventData.description }}</div>
        <div>{{ eventData.dataOra }}</div>
      </v-card-text>
      <v-card-actions>
        <v-btn v-if="auth & !this.book" v-on:click="booking()"> PRENOTA </v-btn>
        <v-btn v-if="!auth" v-on:click="login()"> ACCEDI </v-btn>
        <v-btn v-if="this.book & auth">
          <v-icon>mdi-check-bold</v-icon>
        </v-btn>
        <v-spacer></v-spacer>
        <div v-if="this.book & auth">
            Posti prenotati: {{this.numSeat.toString()}}
        </div>
        <v-spacer></v-spacer>
        <v-btn
          color="red darken-3"
          v-if="this.book & auth"
          v-on:click="delBooking()"
        >
          <v-icon color="black">mdi-delete-forever</v-icon>
        </v-btn>
      </v-card-actions>
    </v-card>
  </div>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";

export default {
  name: "EventForm",
  data: () => ({
    eventData: Object,
    book: Boolean,
    numSeat: Number,
    idEvent: String,
  }),
  props: {
    auth: Boolean,
    idAccount: String,
  },

  methods: {
    login() {
      this.$router.replace({ name: "Login" });
    },
    booking() {
      //ADD funzione prenotazione
      EvenTourDataService.createBooking({
        userId: this.idAccount,
        eventId: this.idEvent,
        prenotedSeat: 1,
      });
      this.book = true;
      this.numSeat=1;
    },
    backHome() {
      this.$router.replace({ name: "Home" });
    },
    getEvent() {
      this.idEvent = this.$route.params.id;
      EvenTourDataService.getEvent(this.idEvent).then((response) => {
        EvenTourDataService.getBookingEventOfUser(
          this.idAccount,
          this.idEvent
        ).then((responseUserEvent) => {
          if (responseUserEvent.data.length < 1) {
            this.book = false;
          } else {
            this.book = true;
            this.numSeat = responseUserEvent.data[0].prenotedSeat;
          }
        });
        this.eventData = response.data;
      });
    },
    delBooking() {
      EvenTourDataService.getBookingEventOfUser(
        this.idAccount,
        this.idEvent
      ).then((responseUserEvent) => {
            EvenTourDataService.deleteBooking(responseUserEvent.data[0].id);
            this.book = false;
            this.numSeat = 0;
      });
    },
  },
  created() {
    //ADD function that retrieve data of event and booking
    //this.getEvent(this.$route.params.id);
  },
  mounted() {
    this.getEvent();
  },
};
</script>

<style scoped>
</style>