<template>
<v-container>
  <div id="event-form">
    <v-btn style="float: right;" tile fab v-on:click="backHome()"> 
        <v-icon color="blue">mdi-home</v-icon>     
    </v-btn>
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-card-title>{{ eventData.title }}</v-card-title>
      <v-card-text>
        <div>{{ eventData.description }}</div>
        <div>{{ this.eventData.location.locality }}</div>
        <div>{{ eventData.dataOra }}</div>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn
          color="red darken-3"
          v-if="authManager"
          v-on:click="delBooking()"
        >
          <v-icon color="black">mdi-delete-forever</v-icon>
        </v-btn>
      </v-card-actions>
    </v-card>

  </div>
  <v-container fluid>
    <list-ticket-manager :idEvent="this.idEvent"/>
  </v-container>
</v-container>
</template>

<script>
import EvenTourDataService from "../services/EvenTourDataService";
import ListTicketManager from "../components/ListTicketsManager.vue"

export default {
  name: "EventForm",
  data: () => ({
    eventData: Object,
    numSeat: Number,
    idEvent: String,
  }),
  props: {
    authManager: Boolean,
    idAccount: String,
  },
  components:{
    ListTicketManager
  },
  methods: {
    login() {
      this.$router.replace({ 
        name: "Login",
        params:{
          manEvId: this.idEvent
        } 
      });
    },
    backHome() {
      this.$router.replace({ name: "HomeManager" });
    },
    getEvent() {
      this.idEvent = this.$route.params.id;
      EvenTourDataService.getEventManager(this.idEvent).then((response) => {
        this.eventData = response.data;
      });
    },
    delBooking() {
      EvenTourDataService.getBookingEventOfUser(
        this.idAccount,
        this.idEvent
      ).then((responseUserEvent) => {
            EvenTourDataService.deleteBooking(responseUserEvent.data[0].id);
            this.book = false;
            this.numSeat = 0;
      });
    },
  },
  created() {
    //ADD function that retrieve data of event and booking
    //this.getEvent(this.$route.params.id);
  },
  mounted() {
    this.getEvent();
  },
};
</script>

<style scoped>
</style>