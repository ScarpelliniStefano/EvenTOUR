module.exports = {
    'Login and Logout Manager' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .assert.value('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .setValue('input[id=password]', 'jesobuje')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/homemanager')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    }
}