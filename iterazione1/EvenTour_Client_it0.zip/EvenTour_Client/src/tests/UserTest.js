module.exports = {
    'Home Page Loading' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('body')
        .assert.titleContains('frontend-springboot-event')
        .waitForElementVisible('div[id=container]')
        .end();
    },
    'From Home to Login' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('button[id=login]')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .end();
    },
    'Login and Logout User' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .assert.value('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    'Login and Try Access Denied' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .url('http://localhost:8080/homemanager')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .end();
    }
}