<template>
  <div class="main">
    <v-container fluid>
      <v-row align="center">
        <v-col
          class="d-flex"
          cols="12"
          sm="4"
        >
          <v-text-field
            v-model="page"
            label="Page"
            hide-details
            single-line
            type="number"
          />
        </v-col>

        <v-col
          class="d-flex"
          cols="12"
          sm="4"
        >
          <v-text-field
            v-model="size"
            hide-details
            single-line
            type="number"
          />
        </v-col>
        <v-col
          cols="12"
          sm="4"
        >
          <v-btn
            width="50%"
            depressed
            color="primary"
            @click="sendMsg()"
          >
            Cerca
          </v-btn>
          <v-btn
            width="50%"
            depressed
            color="primary"
            @click="insert()"
          >
            Inserisci
          </v-btn>
        </v-col>
      </v-row>
    </v-container>
    <v-container fluid>
      <v-row align="center">
        <v-col
          v-for="card in events"
          :key="card.id.toString()"
          :cols="12"
          :sm="6"
          :md="4"
          :lg="3"
          :xl="2"
        >
          <div>
            <v-card
              id="container"
              max-width="600px"
              max-height="600px"
              min-height="300px"
              min-width="280px"
            >
              <v-img
                align="center"
                :src="card.urlImage"
                max-height="200px"
                max-width="600px"
              />
              <v-card-title>
                {{ card.title }}
              </v-card-title>
              <v-card-subtitle>
                {{ card.location.locality }}
                <br>
                {{ card.location.city + " (" + card.location.sigla + ")" }}
                <br>
                {{
                  new Date(card.dataOra).getDate() +
                    "/" +
                    new Date(card.dataOra).getMonth() +
                    "/" +
                    new Date(card.dataOra).getFullYear() +
                    " h." +
                    ('0' + new Date(card.dataOra).getHours()).slice(-2)+
                    ":" +
                    ('0' + new Date(card.dataOra).getMinutes()).slice(-2)
                }}
              </v-card-subtitle>
              <v-card-actions>
                <v-spacer />
                <v-btn
                  icon
                  @click="goToEvent(card.id.toString())"
                >
                  <v-icon>mdi-information-outline</v-icon>
                </v-btn>
              </v-card-actions>
            </v-card>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService.js'

export default {
  name: 'Main',
  props: {
    auth: Boolean,
    idAccount: String
  },
  data: () => ({
    events: [],
    page: '0',
    size: '20',
    param: '',
    order: ''
  }),
  created () {
    const n = this.$route.query.nelem
    const param = this.$route.query.param
    const order = this.$route.query.order
    const p = this.$route.params.npage
    this.page = p < 1 || p == undefined || null ? 1 : p
    this.size = n < 16 || n == undefined || null ? 16 : n
    this.param = param == '' || undefined || null ? '' : param
    this.order = order == '' || undefined || null ? '' : order

    this.retrieveEvents((p <= 0 || p === undefined) ? 0 : p - 1, (n <= 0 || n === undefined) ? 20 : n, param === '' || undefined ? null : param, order === '' || undefined ? 'asc' : order)
  },
  mounted () {
    /* var n = this.$route.query.nelem;
    var param = this.$route.query.param;
    var order = this.$route.query.order;
    var p = this.$route.params.npage;
    this.retrieveEvents(p<=0 || p==undefined ? 0 : p-1, n==undefined ? null : n, param==""||undefined ? null : param, order==""||undefined ? "asc" : order);
  */
  },
  methods: {
    goToEvent (id) {
      this.$router.replace({
        name: 'EventManagerId',
        params: {
          id: id
        }
      })
      location.reload()
    },
    insert () {
      this.$router.replace({
        name: 'InsertEvent',
        query: {
          id: this.idAccount
        }
      })
    },
    sendMsg () {
      // let url = "/p/" + this.page + "?nelem=" + this.size + (this.param == "" ? "" : "&param=" + this.param) + (this.order == "" ? "" : "&order=" + this.order);
      this.param == '' ? null : this.param
      this.order == '' ? null : this.order
      // let url = "/p/" + this.page + "?nelem=" + this.size + (this.param == "" ? "" : "&param=" + this.param) + (this.order == "" ? "" : "&order=" + this.order);
      if (this.param) {
        if (!this.order) {
          this.order = 'asc'
        }
        this.$router.replace({
          name: 'HomeManagerPage',
          params: { np: this.page },
          query: {
            nelem: this.size,
            param: this.param,
            order: this.order
          }
        })
      } else {
        this.$router.replace({
          name: 'HomeManagerPage',
          params: { np: this.page },
          query: {
            nelem: this.size
          }
        })
      }
      location.reload()
      /* this.retrieveE;vents(
        this.page,
        this.size,
        this.param == "" ? null : this.param,
        this.order == "" ? null : this.order
      ); */
    },
    retrieveEvents (p, s, par, ord) {
      EvenTourDataService.getAllPagedEventsManager(p, s, par, ord, this.idAccount)
        .then((response) => {
          this.events = response.data.events
        })
        .catch((e) => {
          console.log(e)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
