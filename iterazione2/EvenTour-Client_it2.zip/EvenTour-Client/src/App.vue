<template>
  <v-app>
    <v-app-bar app color="amber" dark>
      <div id="container" class="d-flex align-center" @click="goHome()">
          <v-img
            alt="Vuetify Logo"
            class="shrink mr-2"
            contain
            src="./assets/logo_img.png"
            transition="scale-transition"
            width="63"
          />

          <v-img
            alt="Vuetify Name"
            class="shrink mt-1 hidden-sm-and-down"
            contain
            min-width="100"
            src="./assets/logo_text.png"
            width="100"
          />
      </div>
      <v-spacer></v-spacer>
      <v-btn id="login" v-if="!auth&&!authInsp&&!authManager" v-on:click="login()" text>
        <span class="mr-2">Login</span>
        <v-icon>mdi-account</v-icon>
      </v-btn>
       <v-btn id="btnReportManager" v-if="authManager" v-on:click="goReportManager()" text>
        <span class="mr-2">Report</span>
        <v-icon>mdi-table</v-icon>
      </v-btn>
      <v-btn id="btnEventour" v-if="auth" v-on:click="goEvenTour()" text>
        <span class="mr-2">EvenTour</span>
        <v-icon>mdi-google-street-view</v-icon>
      </v-btn>
      <v-btn id="btnMyevents" v-if="auth" v-on:click="goMyEvents()" text>
        <span class="mr-2">My Events</span>
        <v-icon>mdi-calendar</v-icon>
      </v-btn>
      <v-btn id="btnSettings" v-if="auth" v-on:click="goSettings()" text>
        <span class="mr-2">Settings</span>
        <v-icon>mdi-cog-outline</v-icon>
      </v-btn>
      <v-btn id="logout" v-if="auth||authManager||authInsp" v-on:click="logout()" text>
        <span class="mr-2">Logout</span>
        <v-icon>mdi-close-circle-outline</v-icon>
      </v-btn>
    </v-app-bar>
    <v-main>
      <router-view
        @auth="setAuth"
        :auth="auth"
        @authinsp="setAuthInsp"
        :authInsp="authInsp"
        @authmanager="setAuthManager"
        :authManager="authManager"
        @infoaccount="setInfoAccount"
        :typeAccount="typeAccount"
        :idAccount="idAccount"
      />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "App",
  data: () => ({
    //Manteniamo la connessione?
    idAccount: "",
    typeAccount: "",
    auth: Boolean,
    authInsp: Boolean,
    authManager: Boolean
  }),
  created() {
    this.falseAuth();
        this.idAccount = this.getCookie("idAccount");
        this.typeAccount = this.getCookie("typeAccount");
        if (
          this.idAccount != null &&
          this.typeAccount != null
        ) {
          if (this.typeAccount === "User") {
            this.setAuth(true);
          } else if (this.typeAccount === "TicketInsp") {
            this.setAuthInsp(true);
          } else if (this.typeAccount === "Manager") {
            this.setAuthManager(true);
          }
        }
      },
  mounted() {
    this.falseAuth();
    this.idAccount = this.getCookie("idAccount");
    this.typeAccount = this.getCookie("typeAccount");
    if (
      this.idAccount != null &&
      this.typeAccount != null
    ) {
      if (this.typeAccount === "User") {
        this.setAuth(true);
      } else if (this.typeAccount === "TicketInsp") {
        this.setAuthInsp(true);
      } else if (this.typeAccount === "Manager") {
        this.setAuthManager(true);
      }
    }
  },
  methods: {
    getCookie(name) {
      var cookieArr = document.cookie.split(";");
      for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1]);
        }
      }
      return null;
    },
    falseAuth() {
      this.auth = false;
      this.authInsp = false;
      this.authManager = false;
    },
    setAuth(status) {
      this.falseAuth();
      this.auth = status;
    },
    setAuthInsp(status) {
      this.falseAuth();
      this.authInsp = status;
    },
    setAuthManager(status) {
      this.falseAuth();
      this.authManager = status;
    },
    setInfoAccount(idAcc, type, timeDay) {
      this.idAccount = idAcc;
      document.cookie = "idAccount=" + encodeURIComponent(idAcc) + ";secure; path=/; max-age="+timeDay * 24 * 60 * 60+"; samesite;";
      this.typeAccount = type;
      document.cookie = "typeAccount=" + encodeURIComponent(type) + ";secure; path=/; max-age="+timeDay * 24 * 60 * 60+"; samesite;";
    },
    goMyEvents(){
      this.$router.replace({name: "EventsBookUser",
        params: {
          id: this.idAccount
        }
      })
    },
    goReportManager(){
      this.$router.replace({
        name: 'ReportManager',
        params: {
          id: this.idAccount
        }
      })
    },
    goEvenTour(){
      this.$router.replace({name: "EvenTour",
        params: {
          id: this.idAccount,
          numEvents: '5'
        }
      })
    },
    goHome(){
      if(this.auth){
        this.$router.replace({ name: "Home" });
      }else if(this.authManager){
        this.$router.replace({ name: "HomeManager" });
      }else if(this.authInsp){
        this.$router.replace({ name: "ScanCode" });
      }else{
        this.$router.replace({ name: "Home" });
      }
    },
    goSettings(){
      this.$router.replace({name: "Settings",
        params: {
          id: this.idAccount
        }
      })
    },
    logout() {
      this.falseAuth();
      this.setInfoAccount("","",0);
      this.$router.replace({name: "Home"});
    },
     login() {
      this.$router.replace({ name: "Login",
        query: {
          page: this.page,
          nelem: this.size,
          param: this.param,
          order: this.order
        }
      });
    },
  },
};
</script>
