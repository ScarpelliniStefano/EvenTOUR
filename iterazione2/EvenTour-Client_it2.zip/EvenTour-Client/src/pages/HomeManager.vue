<template>
  <div>
    <ListEventsManager
      :auth="authManager"
      :id-account="idAccount"
    />
  </div>
</template>

<script>
import ListEventsManager from '../components/ListEventsManager.vue'

export default {
  name: 'HomeManager',

  components: {
    ListEventsManager
  },
  props: {
    authManager: Boolean,
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    page: '0',
    size: '20',
    param: '',
    order: ''
  }),
  created () {
    console.log(this.getCookie('typeAccount'))
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == (null)) {
      this.$router.replace({ name: 'Home' })
    }
  },
  mounted () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == (undefined || null || '' || 'NONE')) {
      this.$router.replace({ name: 'Home' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    logout () {
      this.$emit('auth', false)
      this.$router.replace({ name: 'Home' })
    },
    login () {
      this.$router.replace({
        name: 'Login'
      })
    }
  }
}
</script>
