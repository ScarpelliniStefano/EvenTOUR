<template>
  <v-container>
    <v-text-field
      v-model="information.name"
      placeholder="Name"
    />
    <v-text-field
      v-model="information.surname"
      placeholder="Surname"
    />
    <v-radio-group v-model="information.sex">
      <template #label>
        <div>Sex</div>
      </template>
      <v-radio value="M">
        <template #label>
          <div>M</div>
        </template>
      </v-radio>
      <v-radio value="F">
        <template #label>
          <div>F</div>
        </template>
      </v-radio>
      <v-radio value="*">
        <template #label>
          <div>Other</div>
        </template>
      </v-radio>
    </v-radio-group>
    <v-date-picker v-model="information.datebirth" />
    <v-text-field
      v-model="information.residence"
      placeholder="Residence"
    />
    <v-text-field
      v-model="information.mail"
      placeholder="E-mail"
    />
    <v-text-field
      v-model="information.password"
      placeholder="Password"
      type="password"
    />
    <v-checkbox>Accetto i termini e le condizioni</v-checkbox>
    <v-btn @click="homeauth()">
      Registrati
    </v-btn>
  </v-container>
</template>

<script>
export default {
  name: 'SignupForm',
  data: () => ({
    information: {
      name: '',
      surname: '',
      sex: '',
      datebirth: '',
      residence: '',
      mail: '',
      password: ''
    }
  }),
  methods: {
    homeauth () {
      // Check fields
      this.$router.replace({ name: 'Home' })
    }
  }
}
</script>

<style scoped>
</style>
