import http from "../http-common";
  import axios from 'axios';

class EvenTourDataService {
  getAllEvents() {
    return http.get("/events");
  }

  getAllPagedEvents(page,size,order) {
      if(page==null&&size!==null)
        return http.get(`/events?ordered=${order}&param='dataOra'&page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events?ordered=${order}&param='dataOra'&page=${page}&size=16`);
      if(page!==null&&size!==null)
        return http.get(`/events?ordered=${order}&param='dataOra'&page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events?ordered=${order}&param='dataOra'`);
    
  }

  getAllPagedDataEvents(page,size,dataS) {
    if(page==null&&size!==null)
      return http.get(`/events/data=${dataS}?page=0&size=${size}`);
    if(page!==null&&size==null)
      return http.get(`/events/data=${dataS}?page=${page}&size=16`);
    if(page!==null&&size!==null)
      return http.get(`/events/data=${dataS}?page=${page}&size=${size}`);
    if(page==null&&size==null)
      return http.get(`/events/data=${dataS}`);
  
}

getAllPagedTypeEvents(page,size,typeS) {
  if(page==null&&size!==null)
    return http.get(`/events/type=${typeS}?page=0&size=${size}`);
  if(page!==null&&size==null)
    return http.get(`/events/type=${typeS}?page=${page}&size=16`);
  if(page!==null&&size!==null)
    return http.get(`/events/type=${typeS}?page=${page}&size=${size}`);
  if(page==null&&size==null)
    return http.get(`/events/type=${typeS}`);

}

getAllPagedLocEvents(page,size,typeLocS,locS) {
  if(page==null&&size!==null)
    return http.get(`/events/loc=${typeLocS}/${locS}?page=0&size=${size}`);
  if(page!==null&&size==null)
    return http.get(`/events/loc=${typeLocS}/${locS}?page=${page}&size=16`);
  if(page!==null&&size!==null)
    return http.get(`/events/loc=${typeLocS}/${locS}?page=${page}&size=${size}`);
  if(page==null&&size==null)
    return http.get(`/events/loc=${typeLocS}/${locS}`);

}

getAllPagedPrefEvents(page,size,id){
  if(page==null&&size!==null)
    return http.get(`/events/pref/${id}?page=0&size=${size}`);
  if(page!==null&&size==null)
    return http.get(`/events/pref/${id}?page=${page}&size=16`);
  if(page!==null&&size!==null)
    return http.get(`/events/pref/${id}?page=${page}&size=${size}`);
  if(page==null&&size==null)
    return http.get(`/events/pref/${id}`);
}

  getAllPagedEventsManager(page,size,param,order, id) {
    if(param!=null){
      if(page==null&&size!==null)
        return http.get(`/events/manager/${id}?ordered=${order}&param=${param}&page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events/manager/${id}?ordered=${order}&param=${param}&page=${page}&size=16`);
      if(page!==null&&size!==null)
        return http.get(`/events/manager/${id}?ordered=${order}&param=${param}&page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events/manager/${id}?ordered=${order}&param=${param}`);
    } else {
      if(page==null&&size!==null)
        return http.get(`/events/manager/${id}/manager/${id}?page=0&size=${size}`);
      if(page!==null&&size==null)
        return http.get(`/events/manager/${id}?page=${page}&size=20`);
      if(page!==null&&size!==null)
        return http.get(`/events/manager/${id}?page=${page}&size=${size}`);
      if(page==null&&size==null)
        return http.get(`/events/manager/${id}`);
    }
  }

  getAllPagedEventsUser(id) {
    return http.get(`/bookings/u/${id}`)
  }

  getEventManager(id){
    return http.get(`/events/${id}`)
  }
  
  getEvent(id) {
    return http.get(`/events/${id}`);
  }

  createEvent(data) {
    console.log(data);
    let dateA=data.date.split("-");
    let timeA=data.time.split(":")
    var dataora=new Date(dateA[0],parseInt(dateA[1])-1,dateA[2],parseInt(timeA[0])+1,timeA[1],0,0);
    var dataR={
      "title":data.title,
      "description":data.description,
      "location":{
        "locality":data.location,
        "city":data.selectedCom,
        "cap":data.cap,
        "provincia":data.selectedProv,
        "sigla":data.sigla,
        "regione":data.selectedReg,
        "lat":data.lat,
        "lng":data.lng
      },
      "types":data.types,
      "dataOra":dataora,
      "managerId":data.idAccount,
      "urlImage":data.urlimage,
      "totSeat":parseInt(data.totseat),
      "price":parseFloat(data.price)
    }
    console.log(dataR);
    return http.post("/events", dataR);
  }

  updateEvent(data) {
    let dateA=data.date.split("-");
    let timeA=data.time.split(":")
    var dataora=new Date(dateA[0],parseInt(dateA[1])-1,dateA[2],parseInt(timeA[0])+1,timeA[1],0,0);
    var dataR={
      "id":data.idEvent,
      "title":data.title,
      "description":data.description,
      "location":{
        "locality":data.location,
        "city":data.selectedCom,
        "cap":data.cap,
        "provincia":data.selectedProv,
        "sigla":data.sigla,
        "regione":data.selectedReg,
        "lat":data.lat,
        "lng":data.lng
      },
      "types":data.types,
      "dataOra":dataora,
      "managerId":data.managerId,
      "urlImage":data.urlimage,
      "totSeat":parseInt(data.totseat),
      "price":parseFloat(data.price)
    }
    console.log(data.managerId)
    return http.put(`/events`, dataR);
  }

  updateUser(data) {
    return http.put(`/users`, data);
  }

  deleteEvent(id) {
    return http.delete(`/events/${id}`);
  }

  createTicket(idEv,fullName) {
    var dataR={
      "eventId":idEv,
      "fullName":fullName,
    }
    console.log(dataR);
    return http.post("/ticketInsps", dataR);
  }

  deleteTicket(id) {
    return http.delete(`/ticketInsps/${id}`);
  }

  getLogUser(data){
    return http.post('/account', data);
  }

  getBookingEventOfUser(id, idEv){
    return http.get(`/bookings/user/${id}/event/${idEv}`)
  }

  createBooking(data){
    return http.post(`/bookings`, data);
  }

  deleteBooking(id){
    return http.delete(`/bookings/${id}`);
  }
  
  getTicket(id){
    return http.get(`/ticketInsps/${id}`)
  }

  getCheckCode(data) {
    console.log(data.bookingNr)
    return http.post("/bookings/check", data);
  }

  getTicketInspEvent(idEvent){
    return http.get(`/ticketInsps/event/${idEvent}`);
  }

  getInfoUser(id){
    return http.get(`/users/${id}`)
  }

  async getDataProvCom(prov, com){
      var lat=0;
      var lng=0;
      var cap="";
      var sigla="";
      var regione="";
      let detailsAll;
      var length;
      var i = 0;
      var finded=false;
      var response= await axios
        .get(`https://comuni-ita.herokuapp.com/api/comuni/provincia/${prov}`)
      detailsAll=response.data;
      length = detailsAll.length;
      i = 0;
      finded=false;
      do {
        if(detailsAll[i].nome.toLowerCase()==com.toLowerCase()){
          lat=detailsAll[i].coordinate.lat.valueOf();
          lng=detailsAll[i].coordinate.lng.valueOf();
          cap=detailsAll[i].cap;
          finded=true;
        }
        i=i+1;
      }while(i<length && !finded);
      if(!finded) return null; 
      var responseP=await axios
                      .get(`https://comuni-ita.herokuapp.com/api/province`)
      detailsAll=responseP.data;
      length = detailsAll.length;
      i = 0;
      finded=false;
             
      do { 
        if(detailsAll[i].nome.toLowerCase()==prov.toLowerCase()){
          regione=detailsAll[i].regione;
          regione=(regione.charAt(0).toUpperCase() + regione.slice(1) ).valueOf();
          sigla=detailsAll[i].sigla.toUpperCase().valueOf();
          finded=true;
        }
        i=i+1;
      }while(i<length && !finded); 
      if (!finded) return null; 
      
      return {'city':com,'cap':cap,'provincia':prov,'sigla':sigla,'regione':regione,'lat':lat,'lng':lng}
  }

  payment(data,type){
    return http.post(`/bookings/${type}/payment`, data);
  }

  eventour(id, num){
    return http.get(`/users/${id}/eventour/${num}`)
  }

  reportManager(id){
    return http.get(`/managers/${id}/reports`)
  }
  /*deleteAll() {
    return http.delete(`/events`);
  }*/

}

export default new EvenTourDataService();