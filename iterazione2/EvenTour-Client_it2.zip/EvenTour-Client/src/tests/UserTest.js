module.exports = {
    'Home Page Loading' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('body')
        .assert.titleContains('frontend-springboot-event')
        .waitForElementVisible('div[id=container]')
        .end();
    },
    'From Home to Login' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('button[id=login]')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .end();
    },
    'Login and Logout User' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .assert.value('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    'Login and Try Access Manager Denied' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .url('http://localhost:8080/homemanager')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .end();
    },
    //fase 1
    'Login User EvenTour' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnEventour]')
        .assert.urlEquals('http://localhost:8080/eventour/61a0a933bce0e98fbb2d999d/numevents/5')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=timeline]')
        .waitForElementVisible('div[id=cardEvenTour]')
        .end();
    },
    'Login User EvenTour Payment' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnEventour]')
        .assert.urlEquals('http://localhost:8080/eventour/61a0a933bce0e98fbb2d999d/numevents/5')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=timeline]')
        .waitForElementVisible('div[id=cardEvenTour]')
        .click('button[id=btnPayTour]')
        .waitForElementVisible('input[id=v-card-number]')
        .setValue('input[id=v-card-number]', '4000003800000008')
        .setValue('input[id=v-card-name]', 'Colombi Simone')
        .setValue('select[id=v-card-month]', '02')
        .setValue('select[id=v-card-year]', '22')
        .setValue('input[id=v-card-cvv]', '222')
        .click('button[id=btnPay]')
        .assert.urlEquals('http://localhost:8080/eventour/61a0a933bce0e98fbb2d999d/numevents/5')
        .end();
    },
    'Login User My Event' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnMyevents]')
        .assert.urlEquals('http://localhost:8080/events/user/61a0a933bce0e98fbb2d999d')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=qrcode]')
        .end();
    },
    'Login User Settings' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=btnSettings]')
        .click('button[id=btnSettings]')
        .assert.urlEquals('http://localhost:8080/settings/61a0a933bce0e98fbb2d999d')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('button[id=SaveSettings]')
        .click('button[id=SaveSettings]')
        .assert.urlEquals('http://localhost:8080/')
        .end();
    }
}