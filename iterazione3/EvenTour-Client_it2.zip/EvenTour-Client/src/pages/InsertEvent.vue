<template>
  <v-container>
    <v-text-field
      v-model="information.title"
      placeholder="Title"
      :rules="[() => !!information.title || 'This field is required']"
      prepend-icon="mdi-format-title"
    />
    <v-textarea
      v-model="information.description"
      placeholder="Description"
      :rules="[() => !!information.description || 'This field is required']"
      prepend-icon="mdi-subtitles-outline"
    />

    <v-menu
      ref="menu"
      v-model="menu"
      :close-on-content-click="false"
      :return-value.sync="information.date"
      transition="scale-transition"
      offset-y
      min-width="auto"
    >
      <template #activator="{ on, attrs }">
        <v-text-field
          v-model="information.date"
          label="Pick date"
          prepend-icon="mdi-calendar"
          readonly
          v-bind="attrs"
          v-on="on"
        />
      </template>
      <v-date-picker
        v-model="information.date"
        no-title
        scrollable
        show-adjacent-months
        :allowed-dates="allowedDates"
        :first-day-of-week="1"
        class="mt-4"
        min="2021-11-01"
        max="2024-01-01"
        locale="it-it"
      >
        <v-spacer />
        <v-btn
          text
          color="primary"
          @click="menu = false"
        >
          Cancel
        </v-btn>
        <v-btn
          text
          color="primary"
          @click="$refs.menu.save(information.date)"
        >
          OK
        </v-btn>
      </v-date-picker>
    </v-menu>
    <v-text-field
      v-model="information.time"
      placeholder="Time"
      type="time"
      prepend-icon="mdi-clock-outline"
    />
    <v-select
      v-model="information.selectedReg"
      :items="this.jsonReg"
      label="Regione"
      @change="getProv()"
    />
    <v-select
      v-if="this.jsonProv!=null"
      v-model="information.selectedProv"
      :items="this.jsonProv"
      label="Provincia"
      item-text="nome"
      @change="getCom()"
    />
    <v-select
      v-if="this.jsonCom!=null"
      v-model="information.selectedCom"
      :items="this.jsonCom"
      item-text="nome"
      label="Comune"
    />
    <v-textarea
      v-model="information.location"
      placeholder="Location"
      :rules="[() => !!information.location || 'This field is required']"
      prepend-icon="mdi-map-marker"
      rows="1"
      no-resize
    />
    <v-text-field
      v-model="information.urlimage"
      placeholder="UrlImage"
      type="url"
      prepend-icon="mdi-image"
    />
    <v-container fluid>
      <v-select
        v-model="information.types"
        :items="this.typeList"
        label="Types"
        multiple
      />
    </v-container>
    <v-text-field
      v-model="information.totseat"
      placeholder="TotSeat"
      type="number"
      step="1"
      prepend-icon="mdi-seat-outline"
    />
    <v-text-field
      v-model="information.price"
      placeholder="Price"
      type="number"
      step="0.1"
      suffix="€"
      prepend-icon="mdi-currency-usd"
    />
    <v-btn @click="getData()">
      Inserisci
    </v-btn>
  </v-container>
</template>

<script>
import axios from 'axios'
import EvenTourDataService from '../services/EvenTourDataService.js'
const typesE = [
  { value: '1.1.1', text: 'Concerto - Musica commerciale - Pop' },
  { value: '1.1.2', text: 'Concerto - Musica commerciale - Disco/Dance' },
  { value: '1.1.3', text: 'Concerto - Musica commerciale - Altro' },
  { value: '1.2.1', text: 'Concerto - Rock - Hard rock' },
  { value: '1.2.2', text: 'Concerto - Rock - Metal' },
  { value: '1.2.3', text: 'Concerto - Rock - Punk' },
  { value: '1.2.4', text: 'Concerto - Rock - Altro' },
  { value: '1.3.1', text: 'Concerto - Rap - Trap' },
  { value: '1.3.2', text: 'Concerto - Rap - Freestyle' },
  { value: '1.3.3', text: 'Concerto - Rap - Battle' },
  { value: '1.4.1', text: 'Concerto - Classica - Lirica' },
  { value: '1.4.2', text: 'Concerto - Classica - Orchestrale' },
  { value: '1.4.3', text: 'Concerto - Classica - Strumentale' },
  { value: '1.4.4', text: 'Concerto - Classica - Gospel' },
  { value: '2.1', text: 'Teatro - Musical' },
  { value: '2.2', text: 'Teatro - Commedia' },
  { value: '2.3', text: 'Teatro - Opera lirica' },
  { value: '2.4', text: 'Teatro - Prosa' },
  { value: '2.5', text: 'Teatro - Magia/Cabaret' },
  { value: '2.6', text: 'Teatro - Tragedia' },
  { value: '2.7', text: 'Teatro - Danza' },
  { value: '3.1', text: 'Altri eventi - Sfilata' },
  { value: '3.2', text: 'Altri eventi - Proiezione speciale (non solo al cinema)' },
  { value: '3.3', text: 'Altri eventi - Evento sportivo' },
  { value: '3.4', text: 'Altri eventi - Firmacopie/Presentazione' },
  { value: '3.5', text: 'Altri eventi - Circo' }
]
export default {
  name: 'SignupForm',
  data: () => ({
    information: {
      title: '',
      description: '',
      location: '',
      date: '2021-11-27',
      time: '00:00',
      types: [],
      urlimage: '',
      totseat: '1',
      price: '0',
      selectedReg: '',
      selectedProv: '',
      selectedCom: '',
      sigla: '',
      cap: '',
      lat: '',
      lng: '',
      idAccount: ''
    },
    menu: false,
    typeList: typesE,
    jsonReg: null,
    jsonProv: null,
    jsonCom: null

  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  mounted () {
    const url = 'https://comuni-ita.herokuapp.com/api/regioni'
    axios.get(url).then(response => {
      this.jsonReg = response.data
    })
    const tempo = new Date()
    this.information.date =
                tempo.getFullYear() +
                    '-' +
                (tempo.getMonth() + 1) +
                    '-' +
                tempo.getDate()
    this.information.idAccount = this.$route.query.id
    console.log(this.information.idAccount)
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    getProv () {
      axios
        .get('https://comuni-ita.herokuapp.com/api/province/' + this.information.selectedReg)
        .then(response => {
          this.jsonProv = response.data
        })
    },
    getCom () {
      axios
        .get('https://comuni-ita.herokuapp.com/api/comuni/provincia/' + this.information.selectedProv)
        .then(response => (this.jsonCom = response.data))
    },
    getData () {
      const response = EvenTourDataService.getDataProvCom(this.information.selectedProv, this.information.selectedCom)
      Promise.all([response]).then((result) => {
        this.information.sigla = result[0].sigla
        this.information.cap = result[0].cap
        this.information.lat = result[0].lat
        this.information.lng = result[0].lng
        this.checkInsert()
        console.log(this.information.sigla)
      })
    },
    checkInsert () {
      // Check fields
      // this.getData();

      if (this.information.title !== '' && this.information.description !== '' && this.information.time !== '--:--' &&
                    this.information.types !== [] && this.information.urlimage !== '' && parseInt(this.information.totseat) >= 10 &&
                    parseFloat(this.information.price) >= 0.0 && this.information.selectedCom !== '') {
        EvenTourDataService.createEvent(this.information).then((response) => {
          console.log('risposta: ')
          console.log(response)
          if (response.status == 200) this.$router.replace({ name: 'HomeManager' })
          else console.log(response.status)
        }).catch(console.log)
      } else {
        alert('ricontrolla i dati')
      }
    },
    toggle () {
      this.$nextTick(() => {
        this.typeList = this.information.types.slice()
      })
    },
    allowedDates: val => new Date(val) > new Date()
  }
}
</script>

<style scoped>
</style>
