<template>
  <div>
    <Main
      :type-account="typeAccount"
      :id-account="idAccount"
    />
  </div>
</template>

<script>
import Main from '../components/ListEventsPast.vue'

export default {
  name: 'Home',

  components: {
    Main
  },
  props: {
    typeAccount: String,
    idAccount: String
  },
  data: () => ({
    page: '0',
    size: '20',
    param: '',
    order: ''
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    logout () {
      this.$router.replace({ name: 'Home' })
    }
  }
}
</script>
