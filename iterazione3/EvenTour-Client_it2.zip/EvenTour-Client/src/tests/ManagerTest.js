module.exports = {
    'Login and Logout Manager' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .assert.value('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .setValue('input[id=password]', 'jesobuje')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/homemanager')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    //Fase 1
    'Login Manager Report' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .assert.value('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .setValue('input[id=password]', 'jesobuje')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/homemanager')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnReportManager]')
        .assert.urlEquals('http://localhost:8080/manager/61a0a0eeb5f9b12d06e95237/report')
        .waitForElementVisible('div[id=divReportManager]')
        .end();
    },
    //FASE 2
    'Login Manager Edit Event' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .assert.value('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .setValue('input[id=password]', 'jesobuje')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=EVENTO4103]')
        .click('button[id=EVENTO4103]')
        .assert.urlEquals('http://localhost:8080/events/manager/61a0a85ebce0e98fbb2d9615?idAccount=61a0a0eeb5f9b12d06e95237')
        .waitForElementVisible('button[id=btnEditEvent]')
        .click('button[id=btnEditEvent]')
        .assert.urlEquals('http://localhost:8080/events/manager/edit/61a0a85ebce0e98fbb2d9615')
        .setValue('textarea[id=inputDescription]', 'Nuova Descrizione derivata dai casi di test')
        .waitForElementVisible('input[id=inputRegione]', 10000)
        .setValue('input[id=inputRegione]', 'lombardia')
        .waitForElementVisible('input[id=inputProvincia]', 10000)
        .setValue('input[id=inputProvincia]', 'milano')
        .setValue('input[id=inputComune]', 'Legnano')
        .waitForElementVisible('button[id=btnEdit]')
        .click('button[id=btnEdit]')
        .assert.urlEquals('http://localhost:8080/homemanager')
        .end();
    },
    //Test manuale funziona
    /*
    'Login Manager Add ANd Delete Ticket Inspector' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .assert.value('input[id=username]', 'Domenica.Acquadro@hotmail.com')
        .setValue('input[id=password]', 'jesobuje')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=EVENTO4103]')
        .click('button[id=EVENTO4103]')
        .assert.urlEquals('http://localhost:8080/events/manager/61a0a85ebce0e98fbb2d9615?idAccount=61a0a0eeb5f9b12d06e95237')
        .waitForElementVisible('button[id=btnAddTicketInsp]')
        .click('button[id=btnAddTicketInsp]')
        .waitForElementVisible('button[id=btnAddExistingTI]')
        .waitForElementVisible('input[id=inputExistingTI]')
        .setValue('input[id=inputExistingTI]', 'Niceto Rossi')
        .click('button[id=btnAddTicketInsp]')
        .waitForElementVisible('button[id=NicetoRossi]')
        .click('button[id=NicetoRossi]')
        .waitForElementNotPresent('button[id=NicetoRossi]')
        .end();
    },*/
}