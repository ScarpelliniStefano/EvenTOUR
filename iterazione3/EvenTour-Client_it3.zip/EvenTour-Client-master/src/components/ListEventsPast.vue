<template>
  <div class="main">
    <v-container fluid>
      <v-row align="center">
        <v-col
          class="d-flex"
          cols="12"
          sm="4"
        >
          <v-text-field
            v-model="page"
            label="Page"
            hide-details
            single-line
            type="number"
          />
        </v-col>

        <v-col
          class="d-flex"
          cols="12"
          sm="4"
        >
          <v-text-field
            v-model="size"
            hide-details
            single-line
            type="number"
          />
        </v-col>
        <v-col
          cols="12"
          sm="4"
        >
          <v-btn
            width="50%"
            depressed
            color="primary"
            @click="sendMsg()"
          >
            Cerca
          </v-btn>
        </v-col>
      </v-row>
    </v-container>
    <v-container fluid>
      <v-snackbar
        v-if="nobook"
        :timeout="-1"
        :value="true"
        absolute
        centered
        color="red accent-4"
        elevation="24"
      >
        Nessun evento prenotato.
      </v-snackbar>

      <v-row
        v-if="!nobook"
        align="center"
      >
        <v-col
          v-for="card in events"
          :key="card.eventId.toString()"
          :cols="12"
          :sm="6"
          :md="4"
          :lg="3"
          :xl="2"
        >
          <div>
            <v-card
              id="container"
              max-width="600px"
              max-height="600px"
              min-height="300px"
              min-width="280px"
            >
              <v-img
                align="center"
                :src="card.event[0].urlImage"
                max-height="200px"
                max-width="600px"
              />
              <v-card-title>
                {{ card.event[0].title }}
              </v-card-title>
              <v-card-subtitle>
                <!--{{ card.event[0].locality }}
                <br>
                {{ card.event[0].city + " (" + card.event[0].sigla + ")" }}
                <br>-->
                {{
                  ('0' + new Date(card.event[0].dataOra).getDate()).slice(-2) +
                    "/" +
                    ('0' + new Date(card.event[0].dataOra).getMonth() + 1).slice(-2) +
                    "/" +
                    new Date(card.event[0].dataOra).getFullYear() +
                    " h." +
                    ("0" + new Date(card.event[0].dataOra).getHours()).slice(-2) +
                    ":" +
                    ("0" + new Date(card.event[0].dataOra).getMinutes()).slice(-2)
                }}
              </v-card-subtitle>
              <v-card-actions>
                <v-rating
                  id="divRatings"
                  v-model="card.review"
                  color="yellow darken-3"
                  background-color="red darken-3"
                  empty-icon="$ratingFull"
                  hover
                  large
                  readonly
                  @input="updateReview($event, card.id)"
                  v-if="!card.come"
                />
                <v-rating
                  id="divRatings"
                  v-model="card.review"
                  color="yellow darken-3"
                  background-color="grey darken-1"
                  empty-icon="$ratingFull"
                  hover
                  large
                  @input="updateReview($event, card.id)"
                  v-if="card.come"
                />
              </v-card-actions>
            </v-card>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService.js'
// import VueQRCodeComponent from "vue-qrcode-component";

export default {
  name: 'ListEventsBooked',
  components: {
    // "qr-code": VueQRCodeComponent,
  },
  props: {
    typeAccount: String,
    idAccount: String
  },
  data: () => ({
    events: [],
    rating: -1,
    page: '0',
    size: '20',
    param: '',
    order: '',
    nobook: false
  }),
  created () {
    const n = this.$route.query.nelem
    const param = this.$route.query.param
    const order = this.$route.query.order
    const p = this.$route.params.npage
    this.page = p < 1 || p == undefined || null ? 1 : p
    this.size = n < 16 || n == undefined || null ? 16 : n
    this.param = param == '' || undefined || null ? '' : param
    this.order = order == '' || undefined || null ? '' : order

    this.retrieveEvents(
      p <= 0 || p === undefined ? 0 : p - 1,
      n <= 0 || n === undefined ? 20 : n,
      param === '' || undefined ? null : param,
      order === '' || undefined ? 'asc' : order
    )
  },
  mounted () {
    /* var n = this.$route.query.nelem;
    var param = this.$route.query.param;
    var order = this.$route.query.order;
    var p = this.$route.params.npage;
    this.retrieveEvents(p<=0 || p==undefined ? 0 : p-1, n==undefined ? null : n, param==""||undefined ? null : param, order==""||undefined ? "asc" : order);
  */
  },
  methods: {
    goToEvent (id) {
      // REMOVE questo metodo, le informazioni totali non sono più necessarie, bastano solo alcune informazioni riguardo l'evento
      this.$router.replace({
        name: 'EventId',
        params: {
          id: id
        }
      })
      location.reload()
    },
    updateReview (review, id) {
      console.log(id);
      EvenTourDataService.updateReview({
        bookingNr: id,
        review: review
      }).then(response => {
        console.log(response.data)
        console.log(this.events)
      })
    },
    sendMsg () {
      // let url = "/p/" + this.page + "?nelem=" + this.size + (this.param == "" ? "" : "&param=" + this.param) + (this.order == "" ? "" : "&order=" + this.order);
      if (this.param == '') {
        this.$router.replace({
          name: 'pastEventsPage',
          params: { id: this.idAccount, np: this.page },
          query: {
            nelem: this.size
          }
        })
      } else {
        this.$router.replace({
          name: 'pastEventsPage',
          params: { id: this.idAccount, np: this.page },
          query: {
            nelem: this.size,
            param: this.param,
            order: this.order
          }
        })
      }
      location.reload()
    },
    retrieveEvents () {
      EvenTourDataService.getEventPast(this.idAccount)
        .then((response) => {
          this.events = response.data
          console.log(this.events)
          if (this.events.length !== 0) {
            this.nobook = false
          } else {
            this.nobook = true
          }
        })
        .catch((e) => {
          console.log(e)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
