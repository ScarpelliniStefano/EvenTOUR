<template>
  <div>
    <v-row
      v-if="startPaymentCard && totPayment > 0"
      justify="center"
    >
      <v-dialog
        v-model="startPaymentCard"
        persistent
      >
        <!--  MODULO PAGAMENTO CARTA -->
        <div
          id="app"
          class="wrapper"
        >
          <CardForm
            :form-data="formData"
            @input-card-number="updateCardNumber"
            @input-card-number-not-mask="updateCardNumberNotMask"
            @input-card-name="updateCardName"
            @input-card-month="updateCardMonth"
            @input-card-year="updateCardYear"
            @input-card-cvv="updateCardCvv"
            @input-card-check="closeDialog"
            @close-payment="startPaymentCard = false"
          />
        </div>
      </v-dialog>
    </v-row>
    <v-row
      v-if="startPaymentCardSingle"
      justify="center"
    >
      <v-dialog
        v-model="startPaymentCardSingle"
        persistent
      >
        <!--  MODULO PAGAMENTO CARTA -->
        <div
          id="app"
          class="wrapper"
        >
          <CardForm
            :form-data="formData"
            @input-card-number="updateCardNumber"
            @input-card-number-not-mask="updateCardNumberNotMask"
            @input-card-name="updateCardName"
            @input-card-month="updateCardMonth"
            @input-card-year="updateCardYear"
            @input-card-cvv="updateCardCvv"
            @input-card-check="closeDialogSingle"
            @close-payment="startPaymentCardSingle = false"
          />
        </div>
      </v-dialog>
    </v-row>
    <br>
    <v-sheet
      elevation="1"
      :rounded="true"
      width="200"
      height="70"
      class=" mx-auto d-flex justify-space-between"
    >
      <v-btn
        class="mx-2"
        fab
        large
        color="yellow"
        :disabled="disabledBtn"
        @click="numPeople++; if(numPeople>8) numPeople=1;"
      >
        <h1>{{ numPeople }}</h1>
      </v-btn>
      <v-btn
        class="mx-2"
        fab
        large
        color="yellow"
        :disabled="disabledBtn"
        @click="getEvents()"
      >
        <v-icon large>
          mdi-navigation mdi-rotate-90
        </v-icon>
      </v-btn>
    </v-sheet>
    <v-timeline
      id="timeline"
      align-top
      :dense="$vuetify.breakpoint.smAndDown"
    >
      <v-timeline-item
        v-for="(event, i) in events"
        :key="i"
        color="yellow"
        fill-dot
      >
        <v-card
          id="cardEvenTour"
          color="yellow"
        >
          <v-card-title class="text-h6">
            {{ event.title }}
          </v-card-title>
          <v-card-subtitle>
            {{ event.dataOra }} -
            {{ event.price.toFixed(2) }} €/persona - Posti liberi:
            {{ event.freeSeat }}*
          </v-card-subtitle>
          <v-card-text class="white text--primary">
            {{ event.description }}<br><br>
            <b>Prezzo totale evento: </b>{{ `${event.priceTotPersone} €` }}
            <br>
            <v-btn
              color="yellow"
              class="mx-0"
              outlined
              small
              @click="checkBookSingle(event)"
            >
              Prenota solo questo evento
            </v-btn>
          </v-card-text>
        </v-card>
      </v-timeline-item>
    </v-timeline>
    <center>
      <p>Prezzo totale: {{ totPayment }} €</p>
      <p>Distanza totale (in linea d'aria): {{ totDistance }} Km</p>
      <p>
        <small><i>
          * Non garantiamo la prenotazione di tutti gli eventi a causa di
          aggiornamenti relativi ad altre prenotazioni derivate da altri utenti.
        </i></small>
      </p>
      <v-btn
        id="btnPrenota"
        color="yellow"
        outlined
        x-large
        :disabled="disabledBtn"
        @click="startPaymentCard = true"
      >
        Prenota
      </v-btn>
    </center>
  </div>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService'
import CardForm from '../components/CardForm'

export default {
  name: 'EvenTour',
  components: {
    CardForm
  },
  props: {
    idAccount: String,
    typeAccount: String
  },
  data () {
    return {
      events: [],
      totPayment: 0,
      numPeople: 1,
      totDistance: 0,
      startPayment: false,
      startPaymentCard: false,
      startPaymentCardSingle: false,
      idEventSel: '',
      confirmPayment: false,
      disabledBtn: true,
      txtPayment: 'Pagamento Effettuato',
      formData: {
        cardName: '',
        cardNumber: '',
        cardNumberNotMask: '',
        cardMonth: '',
        cardYear: '',
        cardCvv: ''
      }
    }
  },
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  mounted () {
    this.startPayment = false
    this.getEvents()
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    checkBookSingle (event) {
      if (event.price > 0) {
        this.idEventSel = event.id
        this.startPaymentCardSingle = true
      } else { this.bookingSingle(event) }
    },
    getEvents () {
      this.events = []
      this.totPayment = 0
      this.totDistance = 0
      this.disabledBtn = true
      EvenTourDataService.eventour(
        this.$route.params.id,
        this.$route.params.numEvents,
        this.numPeople
      ).then((response) => {
        this.events = response.data.events
        if (this.events != undefined) {
          this.events.forEach((event) => {
            const time = new Date(event.dataOra)
            const month = time.toLocaleString('default', { month: 'long' })
            event.dataOra =
            time.getDate() +
            ' ' +
            (month) +
            ' ' +
            time.getFullYear() +
            '  h.' +
            ('0' + time.getHours().toString()).slice(-2) +
            ':' +
            ('0' + time.getMinutes()).slice(-2)
          })
          this.totPayment = response.data.totalPrice
          this.totDistance = response.data.totalAirDistance
          this.disabledBtn = false
        } else {
          if (window.location.href.startsWith('http://localhost:8080/eventour/')) {
            alert('Purtroppo non son stati trovati eventi compatibili.')
          }
        }
      }).catch(ex => {
        alert(ex)
      })
    },
    bookingSingle (event) {
      console.log(event.id)
      EvenTourDataService.getEvent(event.id).then((response) => {
        if (response.data.freeSeat < this.numPeople) {
          alert('Nessun posto disponibile per evento: ' + event.title)
        } else {
          EvenTourDataService.createBooking({
            userId: this.idAccount,
            eventId: event.id,
            prenotedSeat: this.numPeople
          })
        }
      })
      this.$router.replace({ name: 'Home' })
    },
    bookEvents () {
      let evProcess = 0
      this.events.forEach((event) => {
        EvenTourDataService.getEvent(event.id).then((response) => {
          if (response.data.freeSeat < this.numPeople) {
            alert('Nessun posto disponibile per evento: ' + event.title)
          } else {
            EvenTourDataService.createBooking({
              userId: this.idAccount,
              eventId: event.id,
              prenotedSeat: this.numPeople
            })
          }
        })
        evProcess++
      })
      while (evProcess < this.events.length) {
        console.log('In attesa...')
      }
      this.$router.replace({ name: 'Home' })
    },
    updateCardNumber (val) {
      this.formData.cardNumber = val
    },
    updateCardNumberNotMask (val) {
      this.formData.cardNumberNotMask = val
    },
    updateCardName (val) {
      this.formData.cardName = val
    },
    updateCardMonth (val) {
      this.formData.cardMonth = val
    },
    updateCardYear (val) {
      this.formData.cardYear = val
    },
    updateCardCvv (val) {
      this.formData.cardCvv = val
    },
    closeDialog () {
      let okEvents = true
      this.events.forEach((event) => {
        EvenTourDataService.getEvent(event.id).then((response) => {
          if (response.data.freeSeat < this.numPeople) {
            alert('Nessun posto disponibile per evento: ' + event.title)
            okEvents = false
          }
        })
      })
      if (okEvents) {
        const dataPay = {
          idUser: this.idAccount,
          cardNr: this.formData.cardNumberNotMask,
          cardName: this.formData.cardName,
          authNr: this.formData.cardCvv,
          date: this.formData.cardMonth + '/' + this.formData.cardYear,
          amount: this.totPayment.toFixed(2)
        }
        EvenTourDataService.payment(dataPay, 'user')
          .then((response) => {
            console.log(response)
            if (response.data.startsWith('OK')) {
              alert(response.data.slice(response.data.indexOf('Transaction')))
              this.startPaymentCard = false
              this.bookEvents()
            } else {
              alert(response.data)
              this.startPaymentCard = true
            }
          })
          .catch((e) => {
            console.error(e)
          })
        this.startPaymentCard = true
      }
    },
    closeDialogSingle () {
      let okEvents = true
      EvenTourDataService.getEvent(this.idEventSel).then((response) => {
        if (response.data.freeSeat < this.numPeople) {
          alert('Nessun posto disponibile per evento: ' + response.data.title)
          okEvents = false
        }
      })
      if (okEvents) {
        const eventSel = this.events.find(element => element.id == this.idEventSel)
        const dataPay = {
          idUser: this.idAccount,
          cardNr: this.formData.cardNumberNotMask,
          cardName: this.formData.cardName,
          authNr: this.formData.cardCvv,
          date: this.formData.cardMonth + '/' + this.formData.cardYear,
          amount: eventSel.priceTotPersone.toFixed(2)
        }
        EvenTourDataService.payment(dataPay, 'user')
          .then((response) => {
            console.log(response)
            if (response.data.startsWith('OK')) {
              alert(response.data.slice(response.data.indexOf('Transaction')))
              this.startPaymentCardSingle = false
              this.bookingSingle(eventSel)
            } else {
              alert(response.data)
              this.startPaymentCardSingle = true
            }
          })
          .catch((e) => {
            console.error(e)
          })
        this.startPaymentCardSingle = true
      }
    }
  }
}
</script>

<style>
</style>
