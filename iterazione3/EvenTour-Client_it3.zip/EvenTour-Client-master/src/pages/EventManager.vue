<template>
  <v-container>
    <div id="event-form">
      <v-btn
        style="float: right;"
        tile
        fab
        @click="backHome()"
      >
        <v-icon color="blue">
          mdi-home
        </v-icon>
      </v-btn>
      <v-card
        id="card"
        class="mx-auto justify-center align-center"
        max-width="500px"
      >
        <v-card-title>{{ eventData.title }}</v-card-title>
        <v-card-text>
          <div>{{ eventData.description }}</div>
          <div>{{ eventData.location.locality }}</div>
          <div>{{ eventData.location.city + " (" + this.eventData.location.sigla + ")" }}</div>
          <div>
            {{
              new Date(eventData.dataOra).getDate() +
                "/" +
                new Date(eventData.dataOra).getMonth() +
                "/" +
                new Date(eventData.dataOra).getFullYear() +
                " h." +
                ('0' + new Date(eventData.dataOra).getHours()).slice(-2)+
                ":" +
                ('0' + new Date(eventData.dataOra).getMinutes()).slice(-2)
            }}
          </div>
        </v-card-text>
        <v-card-actions>
          <v-btn
            id="btnEditEvent"
            icon
            @click="editEvent(eventData.id.toString())"
          >
            <v-icon>mdi-tune</v-icon>
          </v-btn>
          <v-btn
            id="btnDelEvent"
            icon
            color="red"
            @click="deleteEvent(eventData.id.toString())"
          >
            <v-icon>mdi-delete-forever-outline</v-icon>
          </v-btn>
        </v-card-actions>
      </v-card>
    </div>
    <list-ticket-manager :id-event="this.idEvent" />
  </v-container>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService'
import ListTicketManager from '../components/ListTicketsManager.vue'

export default {
  name: 'EventForm',
  components: {
    ListTicketManager
  },
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    eventData: Object,
    numSeat: Number,
    idEvent: String
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
    this.getEvent()
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    login () {
      this.$router.replace({
        name: 'Login'
      })
    },
    backHome () {
      this.$router.replace({ name: 'HomeManager' })
    },
    getEvent () {
      this.idEvent = this.$route.params.id
      EvenTourDataService.getEventManager(this.idEvent).then((response) => {
        console.log(response.data)
        this.eventData = response.data
      }).catch((error) => {
        console.log(error)
      })
    },
    editEvent () {
      this.$router.replace({
        name: 'EditEvent',
        params: {
          id: this.idAccount,
          idEv: this.idEvent
        }
      })
    },
    deleteEvent () {
      EvenTourDataService.deleteEvent(this.idEvent).then(() => {
        this.$router.replace({ name: 'HomeManager' })
      }).catch((err) => {
        console.log(err)
      })
    }
  }
}
</script>

<style scoped>
</style>
