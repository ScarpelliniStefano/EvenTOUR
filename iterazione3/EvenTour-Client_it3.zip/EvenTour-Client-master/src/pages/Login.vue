<template>
  <div id="login-form">
    <v-card
      id="card"
      class="mx-auto justify-center align-center"
      max-width="500px"
    >
      <v-text-field
        id="username"
        v-model="input.username"
        placeholder="Username"
        name="username"
        :rules="[() => !!input.username || 'This field is required']"
      />
      <v-text-field
        id="password"
        v-model="input.password"
        placeholder="Password"
        name="password"
        :append-icon="showP ? 'mdi-eye' : 'mdi-eye-off'"
        :rules="[rules.required, rules.min]"
        :type="showP ? 'text' : 'password'"
        hint="At least 8 characters"
        counter
        @click:append="showP = !showP"
      />
      <v-row
        class="text-center"
        align="center"
        justify="center"
      >
        <v-col
          key="login"
          cols="6"
          sm="6"
          md="12"
          lg="12"
          xl="12"
        >
          <v-btn
            id="btnlogin"
            @click="login(); overlay = !overlay"
          >
            LOGIN
          </v-btn>
          <v-dialog
            v-model="dialogChangePsw"
            persistent
            max-width="600px"
          >
            <template #activator="{ on, attrs }">
              <a
                color="primary"
                dark
                v-bind="attrs"
                v-on="on"
              >
                Ho dimenticato la password
              </a>
            </template>
            <v-card>
              <v-card-title>
                <span class="text-h5">Cambia password</span>
              </v-card-title>
              <v-card-text>
                <v-container>
                  <v-row>
                    <v-col cols="12">
                      <v-text-field
                        v-model="changePsw.mail"
                        label="Email"
                        :rules="[rules.required,rules.mail]"
                      />
                    </v-col>
                    <v-col cols="12">
                      <v-text-field
                        v-model="changePsw.password"
                        label="New password"
                        type="password"
                        :rules="[rules.required,rules.min]"
                      />
                    </v-col>
                    <v-col cols="12">
                      <v-text-field
                        v-model="changePsw.repeatPsw"
                        label="Repeat Password"
                        type="password"
                        :rules="[rules.required,rules.min]"
                      />
                    </v-col>
                  </v-row>
                </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer />
                <v-btn
                  color="blue darken-1"
                  text
                  @click="dialogChangePsw = false"
                >
                  Close
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="changePassword()"
                >
                  Change
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-col>
        <v-col
          key="signup"
          cols="6"
          sm="6"
          md="6"
          lg="6"
          xl="6"
        >
          <v-btn @click="signup()">
            SIGNUP
          </v-btn>
        </v-col>
        <v-col
          key="signupmanager"
          cols="6"
          sm="6"
          md="6"
          lg="6"
          xl="6"
        >
          <v-btn @click="signupManager()">
            SIGNUP MANAGER
          </v-btn>
        </v-col>
      </v-row>
    </v-card>
    <v-overlay
      :color="colorBack"
      :value="overlay"
    >
      <h1>{{ textErrorLogin }}</h1>
    </v-overlay>
  </div>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService.js'
import md5 from 'js-md5'
export default {
  name: 'Login',
  data: () => ({
    input: {
      username: '',
      password: ''
    },
    changePsw: {
      mail: '',
      password: '',
      repeatPsw: ''
    },
    showP: false,
    dialogChangePsw: false,
    overlay: false,
    colorBack: 'white',
    textErrorLogin: '',
    rules: {
      required: value => !!value || 'Required.',
      min: v => v.length >= 8 || 'Min 8 characters',
      mail: value => {
        const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        return pattern.test(value) || 'Invalid e-mail.'
      }
    }
  }),
  watch: {
    overlay (val) {
      val && setTimeout(() => {
        this.overlay = false
      }, 3000)
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    changePassword () {
      if (this.changePsw.mail == '') {
        alert('Compila il campo mail')
      } else if (this.changePsw.password == '' || this.changePsw.repeatPsw == '') {
        alert('Compila il campo password')
      } else if (this.changePsw.password != this.changePsw.repeatPsw) {
        alert('La conferma della password non è corretta')
      } else {
        EvenTourDataService.changePassword({
          user: this.changePsw.mail,
          password: this.changePsw.password
        })
          .then((response) => {
            if (response.data.typeUser != 'NONE') {
              this.colorBack = 'white'
              this.dialogChangePsw = false
            } else {
              this.colorBack = 'red'
              this.textErrorLogin = response.data.user
            }
          })
          .catch((e) => {
            console.log(e)
            this.colorBack = 'red'
            this.textErrorLogin = e
          })
      }
    },
    login () {
      if (this.input.username != '' && this.input.password != '') {
        EvenTourDataService.getLogUser({
          user: this.input.username,
          password: md5(this.input.password)
        })
          .then((response) => {
            if (response.data.typeUser != 'NONE') {
              this.colorBack = 'white'
              this.$emit(
                'infoaccount',
                response.data.user.id,
                response.data.typeUser,
                7
              )
              if (response.data.typeUser == 'User') {
                this.$router.replace({
                  name: 'Home'
                })
              } else if (response.data.typeUser == 'TicketInsp') {
                this.$router.replace({ name: 'ScanCode' })
              } else if (response.data.typeUser == 'Manager') {
                this.$router.replace({ name: 'HomeManager' })
              } else if (response.data.typeUser == 'Admin') {
                this.$router.replace({ name: 'HomeAdmin' })
              }
            } else {
              this.colorBack = 'red'
              this.textErrorLogin = response.data.user
            }
          })
          .catch((e) => {
            console.log(e)
            this.colorBack = 'red'
            this.textErrorLogin = e
          })
      }
    },
    signup () {
      this.$router.replace({ name: 'Signup' })
    },
    signupManager () {
      this.$router.replace({ name: 'SignupMan' })
    }
  }
}
</script>

<style scoped>
#login-form {
  height: auto;
  width: auto;
}
#card {
  margin: 0;
  top: 100px;
  bottom: 100px;
  height: auto;
}
</style>
