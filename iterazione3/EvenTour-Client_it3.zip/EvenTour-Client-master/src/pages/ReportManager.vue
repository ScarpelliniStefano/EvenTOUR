<template>
  <v-card>
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Ricerca"
        single-line
        hide-details
      />
    </v-card-title>
    <v-data-table
      id="divReportManager"
      :headers="headers"
      :items="repoElem"
      :search="search"
      :loading="loadData"
      loading-text="Caricamento in corso..."
    />
  </v-card>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService'
export default {
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    search: '',
    loadData: true,
    headers: [
      {
        text: 'Evento',
        align: 'start',
        value: 'title'
      },
      { text: 'Data Evento', value: 'eventDetails.dataOra' },
      { text: 'Nr. Prenotazioni', value: 'occupedSeat' },
      { text: 'Nr. Effettivo', value: 'comedPeople' },
      { text: 'Saldo', value: 'balance' },
      { text: 'Guadagno Relativo', value: 'lost' },
      { text: 'Media review (0: nessuna recensione)', value: 'reviewMean' }
    ],
    repoElem: [],
    balanceElem: [],
    labelElem: []
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  mounted () {
    EvenTourDataService.reportManager(this.idAccount).then(response => {
      this.repoElem = response.data
      this.repoElem.forEach(element => {
        this.balanceElem.push(element.balance)
      })
      this.loadData=false;
    })
    
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    }
  }
}
</script>

<style>

</style>
