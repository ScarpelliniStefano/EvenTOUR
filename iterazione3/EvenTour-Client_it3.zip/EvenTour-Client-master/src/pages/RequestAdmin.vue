<template>
  <div class="main">
    <v-container fluid>
      <v-row align="center">
        <v-col
          v-for="card in requests"
          :key="card.id"
          :value="card.id.toString()"
          :cols="12"
          :sm="6"
          :md="6"
          :lg="6"
          :xl="6"
        >
          <v-card id="container">
            <v-card-title> {{ card.name }} {{ card.surname }} </v-card-title>
            <v-card-subtitle>
              <b>Mail:</b> {{ card.mail }}
              <b>Via:</b> {{ card.residence.locality }}
              <br>
              <b>Città:</b> {{ card.residence.city + " (" + card.residence.sigla + ")" }}
              <br>
              <b>Data di nascita:</b> {{
                ('0' + new Date(card.dateOfBirth).getDate()).slice(-2)+
                  "/"+
                  ('0'+(new Date(card.dateOfBirth).getMonth()+1)).slice(-2)+
                  "/"+
                  new Date(card.dateOfBirth).getFullYear()
              }}
              <br>
              <b>P.IVA:</b> {{ card.codicePIVA }}
              <br>
              <b>Ragione sociale:</b> {{ card.ragioneSociale }}
            </v-card-subtitle>
            <v-card-actions>
              <v-spacer />
              <!-- funzione da inserire -->
              <v-btn
                icon
                color="green"
                @click="acceptRequest(card.id.toString())"
              >
                <v-icon large>
                  mdi-account-check
                </v-icon>
              </v-btn>

              <v-btn
                icon
                color="red"
                @click="removeRequest(card.id.toString())"
              >
                <v-icon large>
                  mdi-delete
                </v-icon>
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService.js'

export default {
  name: 'RequestsAdmin',
  props: {
    typeAccount: String,
    idAccount: String
  },
  data: () => ({
    requests: [],
    loading: true
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    }
  },
  mounted () {
    // ADD metodo che ricava le richieste disponibili per i manager
    EvenTourDataService.requestAdmin().then(response => {
      console.log(response)
      this.requests = response.data
      this.loading = false
    })
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    acceptRequest (id) {
      EvenTourDataService.acceptRequest(id).then(response => {
        console.log(response)
        if (response.data) {
          alert('request accepted')
          location.reload()
        } else {
          alert('Error with acceptation')
        }
      })
    },
    removeRequest (id) {
      console.log(id)
      EvenTourDataService.removeRequest(id).then(response => {
        console.log(response)
        if (response.data) {
          alert('request deleted')
          location.reload()
        } else {
          alert('Error with delete')
        }
      })
    }
    // ADD metodo che permetta di accettare o rifiutare la richiesta (Aggiunto alla on-click presente nel pulsante)
    //    Se la richiesta è accettata, il manager viene aggiunto all'elenco dei manager
    //    Se la richiesta viene rifiutata, il manager viene tolto dall'elenco degli amministratori
  }

}
</script>

<style scoped>
</style>
