<template>
  <v-container>
    <v-text-field
      v-model="information.name"
      placeholder="Name"
    />
    <v-text-field
      v-model="information.surname"
      placeholder="Surname"
    />
    <v-radio-group v-model="information.sex">
      <template #label>
        <div>Sex</div>
      </template>
      <v-radio value="M">
        <template #label>
          <div>M</div>
        </template>
      </v-radio>
      <v-radio value="F">
        <template #label>
          <div>F</div>
        </template>
      </v-radio>
    </v-radio-group>
    <v-date-picker
      v-model="information.dateOfBirth"
      max="2004-01-01"
      scrollable
      show-adjacent-months
      :allowed-dates="allowedDates"
      :first-day-of-week="1"
      locale="it-it"
    />
    <v-text-field
      v-model="information.residence"
      placeholder="Residence"
    />
    <v-text-field
      v-model="information.codicePIVA"
      placeholder="Partita iva"
    />
    <v-text-field
      v-model="information.ragioneSociale"
      placeholder="Ragione sociale"
    />
    <v-text-field
      v-model="information.mail"
      placeholder="E-mail"
    />
    <v-text-field
      v-model="information.password"
      placeholder="Password"
      type="password"
    />
    <v-checkbox label="Accetto i termini e le condizioni" />
    <v-btn @click="homeauth()">
      Registrati
    </v-btn>
    <v-row
      v-if="startPaymentCard"
      justify="center"
    >
      <v-dialog
        v-model="startPaymentCard"
        persistent
      >
        <!--  MODULO PAGAMENTO CARTA-->
        <div
          id="app"
          class="wrapper"
        >
          <CardForm
            :form-data="formData"
            @input-card-number="updateCardNumber"
            @input-card-number-not-mask="updateCardNumberNotMask"
            @input-card-name="updateCardName"
            @input-card-month="updateCardMonth"
            @input-card-year="updateCardYear"
            @input-card-cvv="updateCardCvv"
            @input-card-check="closeDialog"
          />
        </div>
      </v-dialog>
    </v-row>
  </v-container>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService'
import CardForm from '../components/CardForm'
export default {
  name: 'SignupFormManager',
  components: {
    CardForm
  },
  data: () => ({
    startPaymentCard: false,
    txtPayment: 'Pagamento Effettuato',
    idAccount: '',
    formData: {
      cardName: '',
      cardNumber: '',
      cardNumberNotMask: '',
      cardMonth: '',
      cardYear: '',
      cardCvv: ''
    },
    information: {
      name: '',
      surname: '',
      sex: '',
      dateOfBirth: '2003-12-31',
      residence: '',
      codicePIVA: '',
      ragioneSociale: '',
      mail: '',
      password: ''
    }
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      alert('Sei già registrato.')
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    homeauth () {
      this.txtPayment = 'Pagamento Effettuato'
      this.startPaymentCard = true
    },
    updateCardNumber (val) {
      this.formData.cardNumber = val
    },
    updateCardNumberNotMask (val) {
      this.formData.cardNumberNotMask = val
    },
    updateCardName (val) {
      this.formData.cardName = val
    },
    updateCardMonth (val) {
      this.formData.cardMonth = val
    },
    updateCardYear (val) {
      this.formData.cardYear = val
    },
    updateCardCvv (val) {
      this.formData.cardCvv = val
    },
    closeDialog () {
      this.signupManager()
      const dataPay = {
        idUser: this.idAccount,
        cardNr: this.formData.cardNumberNotMask,
        cardName: this.formData.cardName,
        authNr: this.formData.cardCvv,
        date: this.formData.cardMonth + '/' + this.formData.cardYear,
        amount: (100).toFixed(2)
      }
      EvenTourDataService.paymentM(dataPay).then((response) => {
        console.log(response)
        if (response.data.includes('OK.')) {
          alert(response.data.slice(response.data.indexOf('Transaction')))
          this.txtPayment = 'Pagamento Effettuato'
          this.startPaymentCard = false
        } else {
          alert(response.data)
          this.delManager()
        }
      })
      this.$router.replace({ name: 'Login' })
    },
    signupManager () {
      this.idAccount = '0000'
    },
    delManager () {
      // null
    },
    allowedDates: val => new Date(val) < new Date()
  }
}
</script>

<style scoped>
</style>
