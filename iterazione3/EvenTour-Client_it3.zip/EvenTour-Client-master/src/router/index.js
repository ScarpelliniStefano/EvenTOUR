import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../pages/Home.vue'
import Login from '../pages/Login.vue'
import Signup from '../pages/Signup.vue'
import Event from '../pages/Event.vue'
import ScanCode from '../pages/ScanCode.vue'
import HomeManager from '../pages/HomeManager.vue'
import EventManager from '../pages/EventManager.vue'
import InsertEvent from '../pages/InsertEvent.vue'
import SignupManager from '../pages/SignupManager.vue'
import EventBookUser from '../pages/EventsBookUser.vue'
import Settings from '../pages/UserSettings.vue'
import ManagerSettings from '../pages/ManagerSettings.vue'
import EditEvent from '../pages/EditEvent.vue'
import EvenTour from '../pages/EvenTour.vue'
import ReportManager from '../pages/ReportManager.vue'
import ReportAdmin from '../pages/ReportAdmin.vue'
import RequestAdmin from '../pages/RequestAdmin.vue'
import PastEvent from '../pages/PastEvent.vue'

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Home,
        alias: ["/home","/main","/events"]
    },
    {
        path: '/login',
        name: 'Login',
        component: Login
    },
    {
        path: '/signup',
        name: 'Signup',
        component: Signup
    },
    {
        path: '/signupMan',
        name: 'SignupMan',
        component: SignupManager
    },
    {
        path: '/events/:id',
        name: "EventId",
        component: Event
    },
    {
        path: '/events/p/:npage',
        component: Home
    },
    {
        path: '/events/user/:id',
        name: 'EventsBookUser',
        component: EventBookUser
    },
    {
        path: '/p/:npage',
        name: 'HomePage',
        component: Home
    },
    {
        path: '/scancode',
        name: "ScanCode",
        component: ScanCode
    },
    {
        path: '/homemanager',
        name: "HomeManager",
        component: HomeManager
    },
    {
        path: '/homemanager/p/:np',
        name: "HomeManagerPage",
        component: HomeManager
    },
    {
        path: '/events/manager/:id',
        name: "EventManagerId",
        component: EventManager
    },
    {
        path: '/homemanager/insert',
        name: "InsertEvent",
        component: InsertEvent
    },
    {
        path: '/events/manager/edit/:idEv',
        name: "EditEvent",
        component: EditEvent
    },
    {
        path: '/settings/:id',
        name: "Settings",
        component: Settings
    },
    {
        path: '/settings/manager/:id',
        name: "SettingsManager",
        component: ManagerSettings
    },
    {
        path: '/eventour/:id/numevents/:numEvents',
        name: "EvenTour",
        component: EvenTour
    },
    {
        path: '/manager/:id/report',
        name: 'ReportManager',
        component: ReportManager
    },
    {
        path: '/admin',
        name: 'HomeAdmin',
        component: ReportAdmin
    },
    {
        path: '/admin/requests',
        name: 'requestAdmin',
        component: RequestAdmin
    },
    {
        path: '/ratings/:id',
        name: 'pastEvents',
        component: PastEvent
    },
    {
        path: '/ratings/:id/page/:np',
        name: 'pastEventsPage',
        component: PastEvent
    }
]

const router = new VueRouter({
    mode: 'history',
    routes
})

export default router