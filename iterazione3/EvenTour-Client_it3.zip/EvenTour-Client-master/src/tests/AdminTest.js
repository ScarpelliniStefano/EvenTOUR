module.exports = {
    //Fase 2
    'Login and Logout Admin' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'admin@gmail.com')
        .assert.value('input[id=username]', 'admin@gmail.com')
        .setValue('input[id=password]', 'administrator')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/admin')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    'Login Admin Report' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'admin@gmail.com')
        .assert.value('input[id=username]', 'admin@gmail.com')
        .setValue('input[id=password]', 'administrator')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/admin')
        .click('button[id=btnReportAdmin]')
        .waitForElementVisible('div[id=tableReportAdmin]')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    'Login Admin Requests' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'admin@gmail.com')
        .assert.value('input[id=username]', 'admin@gmail.com')
        .setValue('input[id=password]', 'administrator')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/admin')
        .waitForElementVisible('div[id=tableReportAdmin]')
        .waitForElementVisible('button[id=btnRequestAdmin]')
        .click('button[id=btnRequestAdmin]')
        .assert.urlEquals('http://localhost:8080/admin/requests')
        .click('button[id=logout]')
        .end();
    }
}