module.exports = {
    'Login and Logout Ticket Inspector' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'TI-3696-7017')
        .assert.value('input[id=username]', 'TI-3696-7017')
        .setValue('input[id=password]', 'cetixiye')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/scancode')
        .waitForElementVisible('div[id=cardScanCode]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    //fase 1
    'Login and Logout Ticket Inspector' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'TI-3696-7017')
        .assert.value('input[id=username]', 'TI-3696-7017')
        .setValue('input[id=password]', 'cetixiye')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/scancode')
        .waitForElementVisible('div[id=divReaderQR]')
        .click('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=login]')
        .end();
    }
}