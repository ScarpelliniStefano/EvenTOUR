module.exports = {
    'Home Page Loading' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('body')
        .assert.titleContains('frontend-springboot-event')
        .waitForElementVisible('div[id=container]')
        .end();
    },
    'From Home to Login' : function(browser) {
        browser
        .url('http://localhost:8080')
        .waitForElementVisible('button[id=login]')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .end();
    },
    'Login and Logout User' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .assert.value('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=logout]')
        .waitForElementVisible('button[id=login]')
        .end();
    },
    'Login and Try Access Manager Denied' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .url('http://localhost:8080/homemanager')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .end();
    },

    //fase 1
    'Login User EvenTour' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnEventour]')
        .assert.urlEquals('http://localhost:8080/eventour/61a0a933bce0e98fbb2d999d/numevents/5')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=timeline]')
        .waitForElementNotPresent('div[id=cardEvenTour]')
        .assert.not.enabled('button[id=btnPrenota]')
        .end()
    },
    'Login User My Event' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=btnMyevents]')
        .assert.urlEquals('http://localhost:8080/events/user/61a0a933bce0e98fbb2d999d')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=qrcode]')
        .end()
    },
    //Paginazione di My Events non disponibile
    'Login User Settings' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=btnSettings]')
        .click('button[id=btnSettings]')
        .assert.urlEquals('http://localhost:8080/settings/61a0a933bce0e98fbb2d999d')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('button[id=SaveSettings]')
        .click('button[id=SaveSettings]')
        .assert.urlEquals('http://localhost:8080/')
        .end();
    },
    'Login Info Booking Delete Event' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=logout]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=logout]')
        .click('button[id=EVENTO1841]')
        .assert.urlEquals('http://localhost:8080/events/61a0a85ebce0e98fbb2d8d3f')
        .waitForElementVisible('button[id=btnPrenotaEvento]')
        .click('button[id=btnPrenotaEvento]')
        .waitForElementVisible('button[id=btnAccettaPagamento]')
        .click('button[id=btnAccettaPagamento]')
        .waitForElementVisible('input[id=v-card-number]')
        .setValue('input[id=v-card-number]', '4000003800000008')
        .setValue('input[id=v-card-name]', 'Colombi Simone')
        .setValue('select[id=v-card-month]', '02')
        .setValue('select[id=v-card-year]', '22')
        .setValue('input[id=v-card-cvv]', '222')
        .click('button[id=btnPay]')
        .waitForElementVisible('button[id=btnDelBooking]')
        .click('button[id=btnDelBooking]')
        .waitForElementVisible('button[id=btnPrenotaEvento]')
        .waitForElementVisible('button[id=logout]')
        .end();
    },
    //fase 2
    'Login User Rating' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .waitForElementVisible('button[id=btnRatings]')
        .assert.urlEquals('http://localhost:8080/')
        .waitForElementVisible('button[id=btnRatings]')
        .click('button[id=btnRatings]')
        .assert.urlEquals('http://localhost:8080/ratings/61a0a933bce0e98fbb2d999d')
        .waitForElementVisible('button[id=logout]')
        .waitForElementVisible('div[id=divRatings]')
        .end();
    },
    'Login User Page And Num of Elem' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .assert.urlEquals('http://localhost:8080/')
        .setValue('input[id=inputPage]', '2')
        .setValue('input[id=inputNelem]', '30')
        .click('button[id=btnCerca]')
        .assert.urlEquals('http://localhost:8080/p/2?nelem=30&order=asc')
        .waitForElementVisible('button[id=logout]')
        .end();
    },
    'Login User Pref' : function(browser) {
        browser
        .url('http://localhost:8080')
        .click('button[id=login]')
        .assert.urlEquals('http://localhost:8080/login')
        .setValue('input[id=username]', 'Colombano72@hotmail.com')
        .setValue('input[id=password]', 'yelukare')
        .click('button[id=btnlogin]')
        .assert.urlEquals('http://localhost:8080/')
        .setValue('input[id=inputPage]', '2')
        .setValue('input[id=inputNelem]', '30')
        .click('button[id=btnPreferenze]')
        .assert.urlEquals('http://localhost:8080/p/2?nelem=30&pref=true')
        .waitForElementVisible('button[id=logout]')
        .end();
    },
}