<template>
  <v-app>
    <v-app-bar app color="amber" dark>
      <div id="container" class="d-flex align-center" @click="goHome()">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="./assets/logo_img.png"
          transition="scale-transition"
          width="63"
        />

        <v-img
          alt="Vuetify Name"
          class="shrink mt-1 hidden-sm-and-down"
          contain
          min-width="100"
          src="./assets/logo_text.png"
          width="100"
        />
      </div>
      <v-spacer></v-spacer>
      <v-btn id="login"
        v-if="typeAccount != 'User' && typeAccount != 'TicketInsp' && typeAccount != 'Manager' && typeAccount != 'Admin'"
        v-on:click="login()"
        text
      >
        <span class="mr-2">Login</span>
        <v-icon>mdi-account</v-icon>
      </v-btn>
      <v-btn id="btnRequestAdmin" v-if="typeAccount == 'Admin'" v-on:click="goRequestAdmin()" text>
        <span class="mr-2">Richieste</span>
        <v-icon>mdi-help-circle</v-icon>
      </v-btn>
      <v-btn id="btnReportAdmin" v-if="typeAccount == 'Admin'" v-on:click="goReportAdmin()" text>
        <span class="mr-2">Report</span>
        <v-icon>mdi-table</v-icon>
      </v-btn>
      <v-btn id="btnNewsletter" v-if="typeAccount == 'Admin'" v-on:click="goNewsletter()" text>
        <span class="mr-2">Invio newsletter</span>
        <v-icon>mdi-newspaper-variant-outline</v-icon>
      </v-btn>
      <v-btn id="btnReportManager" v-if="typeAccount == 'Manager'" v-on:click="goReportManager()" text>
        <span class="mr-2">Report</span>
        <v-icon>mdi-table</v-icon>
      </v-btn>
      <v-btn id="btnRatings" v-if="typeAccount == 'User'" v-on:click="goRatings()" text>
        <span class="mr-2">Rate</span>
        <v-icon>mdi-star</v-icon>
      </v-btn>
      <v-btn id="btnEventour" v-if="typeAccount == 'User'" v-on:click="goEvenTour()" text>
        <span class="mr-2">EvenTour</span>
        <v-icon>mdi-google-street-view</v-icon>
      </v-btn>
      <v-btn id="btnMyevents" v-if="typeAccount == 'User'" v-on:click="goMyEvents()" text>
        <span class="mr-2">My Events</span>
        <v-icon>mdi-calendar</v-icon>
      </v-btn>
      <v-btn id="btnSettingsManager" v-if="typeAccount == 'Manager'" v-on:click="goSettingsManager()" text>
        <span class="mr-2">Settings</span>
        <v-icon>mdi-cog-outline</v-icon>
      </v-btn>
      <v-btn id="btnSettings" v-if="typeAccount == 'User'" v-on:click="goSettings()" text>
        <span class="mr-2">Settings</span>
        <v-icon>mdi-cog-outline</v-icon>
      </v-btn>
      <v-btn id="logout" v-if="typeAccount == 'Manager' || typeAccount == 'User' || typeAccount == 'TicketInsp' || typeAccount == 'Admin'" v-on:click="logout()" text>
        <span class="mr-2">Logout</span>
        <v-icon>mdi-close-circle-outline</v-icon>
      </v-btn>
    </v-app-bar>
    <v-main>
      <router-view
        @infoaccount="setInfoAccount"
        :typeAccount="typeAccount"
        :idAccount="idAccount"
      />
    </v-main>
  </v-app>
</template>

<script>
import EvenTourDataService from './services/EvenTourDataService'
export default {
  name: "App",
  data: () => ({
    idAccount: "",
    typeAccount: "",
  }),
  created() {
    this.idAccount = this.getCookie("idAccount");
    this.typeAccount = this.getCookie("typeAccount");
  },
  methods: {
    //Prende le informazioni salvate nei cookie della pagina
    getCookie(name) {
      var cookieArr = document.cookie.split(";");
      for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1]);
        }
      }
      return null;
    },
    //Salva le informazioni dei cookie
    setInfoAccount(idAcc, type, timeDay) {
      this.idAccount = idAcc;
      document.cookie =
        "idAccount=" +
        encodeURIComponent(idAcc) +
        ";secure; path=/; max-age=" +
        timeDay * 24 * 60 * 60 +
        "; samesite;";
      this.typeAccount = type;
      document.cookie =
        "typeAccount=" +
        encodeURIComponent(type) +
        ";secure; path=/; max-age=" +
        timeDay * 24 * 60 * 60 +
        "; samesite;";
    },
    //USER: mostra gli eventi dell'utente
    goMyEvents() {
      this.$router.replace({
        name: "EventsBookUser",
        params: {
          id: this.idAccount,
        },
      });
    },
    //ADMIN: mostra le richieste fatte all'admin
    goRequestAdmin(){
      this.$router.replace({
        name: 'requestAdmin'
      })
    },
    //ADMIN: mostra un report del manager
    goReportAdmin() {
      this.$router.replace({
        name: "HomeAdmin"
      });
    },
    //MANAGER: mostra un report del manager
    goReportManager() {
      this.$router.replace({
        name: "ReportManager",
        params: {
          id: this.idAccount,
        },
      });
    },
    //USER: effettua un EvenTour basato su un numero di eventi decisi dall'utente
    goEvenTour() {
      this.$router.replace({
        name: "EvenTour",
        params: {
          id: this.idAccount,
          numEvents: "5",
        },
      });
    },
    //USER: mostra gli eventi passati per poter dare una valutazione
    goRatings() {
      this.$router.replace({
        name: "pastEvents",
        params: {
          id: this.idAccount,
        },
      });
    },
    //ADMIN: invia la newsletter a chi ne ha fatto richiesta
    goNewsletter(){
      EvenTourDataService.sendNewsletter().then(response => {
        if(response.status==200){
          alert(`E' stata inviata la newsletter a ${response.data} utenti che ne hanno fatto richiesta` );
        }
      });
    },
    //GUI: torna alla home del corrispondente tipo di utente
    goHome() {
      if (this.typeAccount === "User") {
        this.$router.replace({ name: "Home" });
      } else if (this.typeAccount === "Manager") {
        this.$router.replace({ name: "HomeManager" });
      } else if (this.typeAccount === "TicketInsp") {
        this.$router.replace({ name: "ScanCode" });
      } else if (this.typeAccount === "Admin") {
        this.$router.replace({ name: "HomeAdmin" });
      } else {
        this.$router.replace({ name: "Home" });
      }
    },
    //USER: impostazioni
    goSettings() {
      this.$router.replace({
        name: "Settings",
        params: {
          id: this.idAccount,
        },
      });
    },
    //MANAGER: impostazioni
    goSettingsManager() {
      this.$router.replace({
        name: "SettingsManager",
        params: {
          id: this.idAccount,
        },
      });
    },
    //ALL: logout
    logout() {
      this.setInfoAccount("", "", 0);
      this.$router.replace({ name: "Home" });
    },
    //ALL: login
    login() {
      this.$router.replace({
        name: "Login"
      });
    },
  },
};
</script>
