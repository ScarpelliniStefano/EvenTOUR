<template>
  <v-container>
    <v-text-field
      v-model="information.title"
      placeholder="Title"
      :rules="[() => !!information.title || 'This field is required']"
      prepend-icon="mdi-format-title"
    />
    <v-textarea
      id="inputDescription"
      v-model="information.description"
      placeholder="Description"
      :rules="[() => !!information.description || 'This field is required']"
      prepend-icon="mdi-subtitles-outline"
    />

    <v-textarea
      v-model="information.location"
      placeholder="Location"
      :rules="[() => !!information.location || 'This field is required']"
      prepend-icon="mdi-subtitles-outline"
      rows="1"
      no-resize
    />

    <v-menu
      ref="menu"
      v-model="menu"
      :close-on-content-click="false"
      :return-value.sync="information.date"
      transition="scale-transition"
      offset-y
      min-width="auto"
    >
      <template #activator="{ on, attrs }">
        <v-text-field
          v-model="information.date"
          label="Pick date"
          prepend-icon="mdi-calendar"
          readonly
          v-bind="attrs"
          v-on="on"
        />
      </template>
      <v-date-picker
        v-model="information.date"
        no-title
        scrollable
        :allowed-dates="allowedDates"
        class="mt-4"
        min="2021-11-01"
        max="2024-01-01"
      >
        <v-spacer />
        <v-btn
          text
          color="primary"
          @click="menu = false"
        >
          Cancel
        </v-btn>
        <v-btn
          text
          color="primary"
          @click="$refs.menu.save(information.date)"
        >
          OK
        </v-btn>
      </v-date-picker>
    </v-menu>
    <v-text-field
      v-model="information.time"
      placeholder="Time"
      type="time"
      prepend-icon="mdi-clock-outline"
    />

    <v-select
      id="inputRegione"
      v-model="information.selectedReg"
      :items="this.jsonReg"
      label="Regione"
      @change="getProv()"
    />
    <v-select
      v-if="this.jsonProv != null"
      id="inputProvincia"
      v-model="information.selectedProv"
      :items="this.jsonProv"
      label="Provincia"
      @change="getCom()"
    />

    <v-select
      v-if="this.jsonCom != null"
      id="inputComune"
      v-model="information.selectedCom"
      :items="this.jsonCom"
      label="Comune"
    />

    <v-text-field
      v-model="information.urlimage"
      placeholder="UrlImage"
      type="url"
      prepend-icon="mdi-image"
    />

    <v-container fluid>
      <v-select
        v-model="information.typeList"
        :items="this.typeList"
        label="Types"
        multiple
      >
        <template #prepend-item>
          <v-list-item
            ripple
            @click="toggle"
          >
            <v-list-item-action>
              <v-icon
                :color="information.typeList.value > 0 ? 'indigo darken-4' : ''"
              >
                {{ icon }}
              </v-icon>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title> Select All </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-divider class="mt-2" />
        </template>
        <template #append-item>
          <v-divider class="mb-2" />
        </template>
      </v-select>
    </v-container>

    <v-text-field
      v-model="information.totseat"
      placeholder="TotSeat"
      type="number"
      step="1"
      min="10"
      prepend-icon="mdi-seat-outline"
    />

    <v-text-field
      v-model="information.price"
      placeholder="Price"
      type="number"
      step="0.1"
      suffix="€"
      min="0"
      disabled
      prepend-icon="mdi-currency-usd"
    />
    <v-btn
      id="btnEdit"
      @click="getData()"
    >
      Modifica Evento
    </v-btn>
  </v-container>
</template>

<script>
import axios from 'axios'
import EvenTourDataService from '../services/EvenTourDataService.js'
const typesE = [
  { value: '1.1.1', text: 'Concerto - Musica commerciale - Pop' },
  { value: '1.1.2', text: 'Concerto - Musica commerciale - Disco/Dance' },
  { value: '1.1.3', text: 'Concerto - Musica commerciale - Altro' },
  { value: '1.2.1', text: 'Concerto - Rock - Hard rock' },
  { value: '1.2.2', text: 'Concerto - Rock - Metal' },
  { value: '1.2.3', text: 'Concerto - Rock - Punk' },
  { value: '1.2.4', text: 'Concerto - Rock - Altro' },
  { value: '1.3.1', text: 'Concerto - Rap - Trap' },
  { value: '1.3.2', text: 'Concerto - Rap - Freestyle' },
  { value: '1.3.3', text: 'Concerto - Rap - Battle' },
  { value: '1.4.1', text: 'Concerto - Classica - Lirica' },
  { value: '1.4.2', text: 'Concerto - Classica - Orchestrale' },
  { value: '1.4.3', text: 'Concerto - Classica - Strumentale' },
  { value: '1.4.4', text: 'Concerto - Classica - Gospel' },
  { value: '2.1', text: 'Teatro - Musical' },
  { value: '2.2', text: 'Teatro - Commedia' },
  { value: '2.3', text: 'Teatro - Opera lirica' },
  { value: '2.4', text: 'Teatro - Prosa' },
  { value: '2.5', text: 'Teatro - Magia/Cabaret' },
  { value: '2.6', text: 'Teatro - Tragedia' },
  { value: '2.7', text: 'Teatro - Danza' },
  { value: '3.1', text: 'Altri eventi - Sfilata' },
  {
    value: '3.2',
    text: 'Altri eventi - Proiezione speciale (non solo al cinema)'
  },
  { value: '3.3', text: 'Altri eventi - Evento sportivo' },
  { value: '3.4', text: 'Altri eventi - Firmacopie/Presentazione' },
  { value: '3.5', text: 'Altri eventi - Circo' }
]
export default {
  name: 'EditForm',
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    information: {
      title: '',
      description: '',
      location: '',
      date: '',
      time: '00:00',
      typeList: [],
      urlimage: '',
      totseat: '1',
      price: '0',
      managerId: '',
      sigla: '',
      cap: '',
      lat: '',
      lng: '',
      idEvent: '',

      selectedReg: '',
      selectedProv: '',
      selectedCom: ''
    },
    menu: false,
    typeList: typesE,
    selectedAllTypes: 'false',

    jsonReg: null,
    jsonProv: null,
    jsonCom: null,

    jsonProvTot: null,
    jsonComTot: null,

    regMod: false
  }),
  computed: {
    chooseAllTypes () {
      return this.information.typeList.length === this.typeList.length
    },
    chooseSomeTypes () {
      return this.information.typeList.length > 0
    },
    icon () {
      if (this.chooseAllTypes) return 'mdi-close-box'
      if (this.chooseSomeTypes) return 'mdi-minus-box'
      return 'mdi-checkbox-blank-outline'
    }
  },
  mounted () {
    const url = 'https://comuni-ita.herokuapp.com/api/regioni'
    axios.get(url).then((response) => {
      this.jsonReg = response.data
    })
    this.getEvent()
  },
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    getEvent () {
      this.information.idEvent = this.$route.params.idEv
      EvenTourDataService.getEvent(this.information.idEvent).then((response) => {
        console.log(response)
        this.information.managerId = response.data.managerId
        this.information.title = response.data.title
        this.information.description = response.data.description
        this.information.selectedReg =
          response.data.location.regione.toLowerCase()
        this.information.selectedProv =
          response.data.location.provincia.toLowerCase()
        this.information.selectedCom = response.data.location.city
        this.getProv()
        this.information.location = response.data.location.locality
        const tempo = new Date(response.data.dataOra)
        this.information.date =
          tempo.getFullYear() +
          '-' +
          (tempo.getMonth() + 1) +
          '-' +
          tempo.getDate()
        this.information.time =
          ('0' + tempo.getHours().toString()).slice(-2) +
          ':' +
          ('0' + tempo.getMinutes()).slice(-2)
        this.information.typeList = response.data.types
        this.information.urlimage = response.data.urlImage
        this.information.totseat = response.data.totSeat
        this.information.price = response.data.price
      })
    },
    getProv () {
      axios
        .get(
          'https://comuni-ita.herokuapp.com/api/province/' +
            this.information.selectedReg
        )
        .then((response) => {
          this.jsonProv = response.data.map((prov) => prov.nome)
          if (!this.regMod) {
            this.regMod = true
            this.getCom()
          }
        })
    },
    getCom () {
      axios
        .get(
          'https://comuni-ita.herokuapp.com/api/comuni/provincia/' +
            this.information.selectedProv
        )
        .then((response) => {
          this.jsonCom = response.data.map((com) => com.nome)
        })
    },
    getData () {
      const response = EvenTourDataService.getDataProvCom(this.information.selectedProv, this.information.selectedCom)
      Promise.all([response]).then((result) => {
        this.information.sigla = result[0].sigla
        this.information.cap = result[0].cap
        this.information.lat = result[0].lat
        this.information.lng = result[0].lng
        this.homemanager()
      })
    },
    homemanager () {
      if (this.information.title !== '' && this.information.description !== '' && this.information.location !== '' && this.information.time !== '--:--' &&
        this.information.typeList !== [] && this.information.urlimage !== '' && parseInt(this.information.totseat) > 10 &&
        parseFloat(this.information.price) >= 0.0 && this.information.selectedCom !== '') {
        EvenTourDataService.updateEvent(this.information).then((response) => {
          console.log(response)
          if (response.status == 200) this.$router.replace({ name: 'HomeManager' })
          else console.log(response.status)
        }).catch(console.log)
      } else {
        alert('ricontrolla i dati')
      }
    },
    toggle () {
      this.selectedAllTypes = !this.selectedAllTypes
      this.$nextTick(() => {
        if (!this.selectedAllTypes) {
          this.information.typeList = this.typeList
        } else {
          this.information.typeList = []
        }
      })
    },
    allowedDates: (val) => new Date(val) > new Date()
  }
}
</script>

<style scoped>
</style>
