<template>
  <div>
    <ListEventsManager
      :type-account="typeAccount"
      :id-account="idAccount"
    />
  </div>
</template>

<script>
import ListEventsManager from '../components/ListEventsManager.vue'

export default {
  name: 'HomeManager',

  components: {
    ListEventsManager
  },
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    page: '0',
    size: '20',
    param: '',
    order: ''
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    logout () {
      this.$router.replace({ name: 'Home' })
    },
    login () {
      this.$router.replace({
        name: 'Login'
      })
    }
  }
}
</script>
