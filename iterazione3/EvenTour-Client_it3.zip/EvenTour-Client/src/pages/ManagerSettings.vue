<template>
  <v-container>
    <v-text-field
      v-model="information.name"
      placeholder="Name"
      disabled
      prepend-icon="mdi-format-title"
    />
    <v-text-field
      v-model="information.surname"
      placeholder="Surname"
      disabled
      prepend-icon="mdi-format-title"
    />
    <v-menu
      ref="menu"
      v-model="menu"
      :close-on-content-click="false"
      :return-value.sync="information.dateOfBirth"
      transition="scale-transition"
      offset-y
      min-width="auto"
    >
      <template #activator="{ on, attrs }">
        <v-text-field
          v-model="information.dateOfBirth"
          disabled
          label="Date of birth"
          prepend-icon="mdi-calendar"
          readonly
          v-bind="attrs"
          v-on="on"
        />
      </template>
      <v-date-picker
        v-model="information.dateOfBirth"
        no-title
        scrollable
        :allowed-dates="allowedDates"
        class="mt-4"
        min="2021-11-01"
        max="2024-01-01"
      />
    </v-menu>

    <v-select
      v-model="information.selectedReg"
      :items="this.jsonReg"
      label="Regione"
      prepend-icon="mdi-crosshairs-gps"
      @change="getProv()"
    />
    <v-select
      v-if="this.jsonProv != null"
      v-model="information.selectedProv"
      :items="this.jsonProv"
      label="Provincia"
      prepend-icon="mdi-map-marker"
      @change="getCom()"
    />

    <v-select
      v-if="this.jsonCom != null"
      v-model="information.selectedCom"
      :items="this.jsonCom"
      label="Comune"
      prepend-icon="mdi-city"
    />
    <v-text-field
      v-model="information.locality"
      placeholder="Via/Piazza"
      prepend-icon="mdi-google-street-view"
    />

    <v-text-field
      v-model="information.codicePIVA"
      placeholder="Codice Partita IVA"
      disabled
      prepend-icon="mdi-text-short"
    />

    <v-text-field
      v-model="information.mail"
      placeholder="Mail"
      disabled
      prepend-icon="mdi-email"
    />

    <v-text-field
      v-model="information.password"
      type="password"
      placeholder="Password"
      disabled
      prepend-icon="mdi-lock"
    />

    <v-text-field
      v-model="information.ragioneSociale"
      placeholder="Ragione Sociale"
      disabled
      prepend-icon="mdi-briefcase"
    />

    <v-btn @click="getData()">
      Salva Impostazioni
    </v-btn>
  </v-container>
</template>

<script>
import axios from 'axios'
import EvenTourDataService from '../services/EvenTourDataService.js'
export default {
  name: 'EditManagerForm',
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    information: {
      name: '',
      surname: '',
      dateOfBirth: '',
      mail: '',
      password: '',
      locality: '',
      ragioneSociale: '',
      codicePIVA: '',

      sigla: '',
      cap: '',
      lat: '',
      lng: '',

      selectedReg: '',
      selectedProv: '',
      selectedCom: ''
    },
    menu: false,
    jsonReg: null,
    jsonProv: null,
    jsonCom: null,
    regMod: false
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  mounted () {
    const url = 'https://comuni-ita.herokuapp.com/api/regioni'
    axios.get(url).then((response) => {
      this.jsonReg = response.data
    })
    this.getEvent()
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    getEvent () {
      EvenTourDataService.getInfoManager(this.idAccount).then((response) => {
        console.log(response.data)
        this.information.name = response.data.name
        this.information.surname = response.data.surname
        this.information.selectedReg =
          response.data.residence.regione.toLowerCase()
        this.information.selectedProv =
          response.data.residence.provincia.toLowerCase()
        this.information.selectedCom = response.data.residence.city
        this.getProv()
        this.information.locality = response.data.residence.locality
        const tempo = new Date(response.data.dateOfBirth)
        const month = tempo.toLocaleString('default', { month: 'long' })
        this.information.dateOfBirth =
          tempo.getDate() +
          ' ' +
          (month) +
          ' ' +
          tempo.getFullYear()
          console.log(response.data.codicePIVA)
        this.information.codicePIVA = response.data.codicePIVA
        this.information.mail = response.data.mail
        this.information.password = response.data.password
        this.information.ragioneSociale = response.data.ragioneSociale
      })
    },
    getProv () {
      axios
        .get(
          'https://comuni-ita.herokuapp.com/api/province/' +
            this.information.selectedReg
        )
        .then((response) => {
          this.jsonProv = response.data.map((prov) => prov.nome)
          if (!this.regMod) {
            this.regMod = true
            this.getCom()
          } else {
            this.jsonCom = null
          }
        })
    },
    getCom () {
      axios
        .get(
          'https://comuni-ita.herokuapp.com/api/comuni/provincia/' +
            this.information.selectedProv
        )
        .then((response) => {
          this.jsonCom = response.data.map((com) => com.nome)
        })
    },
    getData () {
      const response = EvenTourDataService.getDataProvCom(this.information.selectedProv, this.information.selectedCom)
      Promise.all([response]).then((result) => {
        console.log(result[0])
        this.information.sigla = result[0].sigla
        this.information.cap = result[0].cap
        this.information.lat = result[0].lat
        this.information.lng = result[0].lng
        this.home()
      })
    },
    home () {
      // Check Fields
      if (this.information.selectedCom !== '') {
        EvenTourDataService.updateManager({
          id: this.idAccount,
          residence: {
            regione: this.information.selectedReg,
            sigla: this.information.sigla,
            cap: this.information.cap,
            provincia: this.information.selectedProv,
            lat: this.information.lat,
            lng: this.information.lng,
            city: this.information.selectedCom,
            locality: this.information.locality
          }
        }
        ).then((response) => {
          if (response.data == null) {
            alert('modifica non andata a buon fine')
          } else {
            console.log(response)
            this.$router.replace({ name: 'HomeManager' })
          }
        })
      }
    },
    allowedDates: (val) => new Date(val) > new Date()
  }
}
</script>

<style scoped>
</style>
