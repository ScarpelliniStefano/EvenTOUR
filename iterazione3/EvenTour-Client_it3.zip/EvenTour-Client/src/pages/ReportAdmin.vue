<template>
  <v-card>
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Ricerca"
        single-line
        hide-details
      />
    </v-card-title>
    <v-data-table
      id="tableReportAdmin"
      :headers="headers"
      :items="repoElem"
      :search="search"
      :loading="loading"
      loading-text="Caricamento in corso... Attendere."
    >
      <template #top>
        <v-toolbar
          flat
        >
          <v-toolbar-title>Managers</v-toolbar-title>
          <v-divider
            class="mx-4"
            inset
            vertical
          />
          <v-spacer />
        </v-toolbar>
      </template>
      <template #[`item.actions`]="{ item }">
        <v-icon
          small
          class="mr-2"
          @click="malus(item)"
        >
          mdi-virus
        </v-icon>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import EvenTourDataService from '../services/EvenTourDataService'
export default {
  props: {
    idAccount: String,
    typeAccount: String
  },
  data: () => ({
    search: '',
    loading: true,
    headers: [
      {
        text: 'Partita IVA',
        align: 'start',
        filterable: true,
        value: 'codicePIVA'
      },
      {
        text: 'Ragione sociale',
        value: 'managerDetails.ragioneSociale'
      },
      { text: 'Nome', value: 'managerDetails.name' },
      { text: 'Cognome', value: 'managerDetails.surname' },
      { text: 'Data di rinnovo', value: 'managerDetails.dateRenewal' },
      { text: 'Media Posti', value: 'comesMean' },
      { text: 'Numero Eventi', value: 'numEventi' },
      { text: 'Numero Eventi Futuri', value: 'numFuturi' },
      { text: 'Rating', value: 'rating' },
      { text: 'Actions', value: 'actions', sortable: false }
    ],
    repoElem: [],
    balanceElem: [],
    labelElem: []
  }),
  created () {
    console.log(this.getCookie('typeAccount'))
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    }
  },
  mounted () {
    EvenTourDataService.reportAdmin().then(response => {
      console.log(response.data)
      this.repoElem = response.data
      this.repoElem.forEach(element => {
        element.managerDetails.dateRenewal = ('0' + new Date(element.managerDetails.dateRenewal).getDate()).slice(-2) +
                                        '/' +
                                  ('0' + (new Date(element.managerDetails.dateRenewal).getMonth() + 1)).slice(-2) +
                                        '/' +
                                  new Date(element.managerDetails.dateRenewal).getFullYear()
      })
      this.loading = false
    }).catch(() => {
      this.loading = false
    })
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    malus (item) {
      console.log(item.id)
      const control = new Date().setFullYear(new Date().getFullYear() - 1)
      console.log(control)
      if (new Date(item.managerDetails.dateRenewal) > control) {
        EvenTourDataService.malusManager(item.id).then(response => {
          console.log(response)
          if (response.data) {
            alert('malus applied')
            location.reload()
          } else {
            alert('Error with malus')
          }
        })
      } else {
        alert('malus not applied: the malus can only be applied to active managers and not with renewal to be done')
      }
    }
  }
}
</script>

<style>

</style>
