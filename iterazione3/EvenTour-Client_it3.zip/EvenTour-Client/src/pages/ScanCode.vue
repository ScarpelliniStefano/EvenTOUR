<template>
  <div>
    <v-card v-if="typeAccount == 'TicketInsp'">
      <v-card-title>Scannerizza Codice</v-card-title>
      <v-card-text>
        <div class="limit">
          <qrcode-stream
            :camera="camera"
            @decode="onDecode"
            @init="onInit"
          >
            <div
              v-if="validationSuccess"
              class="validation-success"
            >
              ACCESS GRANTED
            </div>

            <div
              v-if="validationFailure"
              class="validation-failure"
            >
              {{ textConfirm }}
            </div>

            <div
              v-if="validationPending"
              class="validation-pending"
            >
              validation...
            </div>
          </qrcode-stream>
        </div>
        <v-text-field
          v-model="code"
          placeholder="Insert Code..."
        />
      </v-card-text>
      <v-card-actions>
        <v-btn @click="checkCode(); overlay = !overlay">
          <v-icon>mdi-tick-circle-outline</v-icon>
          Check
        </v-btn>
      </v-card-actions>
    </v-card>
    <v-overlay
      :color="colorBack"
      :value="overlay"
    >
      <h1>{{ textConfirm }}</h1>
    </v-overlay>
    <v-card v-if="typeAccount !== 'TicketInsp'">
      <v-card-title>Nessuna autorizzazione.</v-card-title>
      <v-btn @click="backHome()">
        HOME
      </v-btn>
    </v-card>
  </div>
</template>

<script>
// ticket Insp code: TI-3696-7017  (id: 61a0b05abce0e98fbb2dad3c)
// ticket insp password: cetixiye
// booking ok: 61a8c63a648e0931525cd2a0
// booking no (no code booking ok): 61a0a933bce0e98fbb2d999d
// booking no (no event correct): 61b4ef384518cc696cb67606
import EvenTourDataService from '../services/EvenTourDataService'
import { QrcodeStream } from 'vue-qrcode-reader'

export default {
  name: 'ScanCode',
  components: { QrcodeStream },
  props: {
    typeAccount: String,
    idAccount: String
  },
  data: () => ({
    isValid: undefined,
    camera: 'auto',
    code: '',
    textConfirm: '',
    idEventTmp: '',
    overlay: false,
    colorBack: 'white'
  }),
  computed: {
    validationPending () {
      return this.isValid === undefined &&
                this.camera === 'off'
    },

    cameraNotPresent () {
      return this.camera === 'off'
    },

    validationSuccess () {
      return this.isValid === true
    },

    validationFailure () {
      return this.isValid === false
    }
  },
  created () {
    if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == 'User') {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == null) {
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    onInit (promise) {
      promise
        .catch(console.error)
        .then(this.resetValidationState)
    },

    resetValidationState () {
      this.isValid = undefined
    },

    async onDecode (content) {
      this.code = content
      this.checkCode()
      this.turnCameraOff()

      await this.timeout(1000)
      this.isValid = (this.textConfirm == 'ACCESS GRANTED')

      // some more delay, so users have time to read the message
      await this.timeout(1000)

      this.turnCameraOn()
    },

    turnCameraOn () {
      this.camera = 'auto'
    },

    turnCameraOff () {
      this.camera = 'off'
    },

    timeout (ms) {
      return new Promise(resolve => {
        window.setTimeout(resolve, ms)
      })
    },
    logout () {
      this.$router.replace({ name: 'Home' })
    },
    backHome () {
      this.$router.replace({ name: 'Home' })
    },
    checker () {
      EvenTourDataService.getCheckCode({
        bookingNr: this.code,
        eventId: this.idEventTmp
      }).then((response) => {
        console.log(response.data)
        if (response.data == 'ACCESS GRANTED') {
          this.colorBack = 'green'
        } else {
          this.colorBack = 'red'
        }
        this.textConfirm = response.data
        this.code = ''
      })
    },
    checkCode () {
      if (this.idEventTmp == '') {
        EvenTourDataService.getTicket(this.idAccount)
          .then((response) => {
            this.idEventTmp = response.data.eventId
            this.checker()
          })
      } else {
        this.checker()
      }
    }
  }
}
</script>

<style scoped>
.validation-success,
.validation-failure,
.validation-pending {
  position: absolute;
  width: 100%;
  height: 100%;

  background-color: rgba(255, 255, 255, .8);
  text-align: center;
  font-weight: bold;
  font-size: 1.4rem;
  padding: 10px;

  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
}
.validation-success {
  color: green;
}
.validation-failure {
  color: red;
}

div.limit{
    width: 30vmax;
    margin: auto;
    border: 3px solid aquamarine;
}
</style>
