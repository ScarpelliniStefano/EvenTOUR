<template>
  <v-container fluid>
    <v-text-field
      v-model="information.name"
      placeholder="Name"
    />
    <v-text-field
      v-model="information.surname"
      placeholder="Surname"
    />
    <v-text-field
      v-model="information.username"
      placeholder="Username"
    />
    <v-radio-group v-model="information.sex">
      <template #label>
        <div>Sex</div>
      </template>
      <v-radio value="M">
        <template #label>
          <div>M</div>
        </template>
      </v-radio>
      <v-radio value="F">
        <template #label>
          <div>F</div>
        </template>
      </v-radio>
    </v-radio-group>
    <v-date-picker v-model="information.dateOfBirth" />
    <v-text-field
      v-model="information.mail"
      placeholder="E-mail"
    />
    <v-text-field
      v-model="information.password"
      placeholder="Password"
      type="password"
    />
    <v-checkbox>Accetto i termini e le condizioni</v-checkbox>
    <v-btn @click="homeauth()">
      Registrati
    </v-btn>
  </v-container>
</template>

<script>
export default {
  name: 'SignupForm',
  data: () => ({
    information: {
      name: '',
      surname: '',
      username: '',
      sex: '',
      dateOfBirth: '',
      residence: {
        locality: '',
        city: '',
        cap: '',
        provincia: '',
        sigla: '',
        regione: '',
        lat: 0.000000000,
        lng: 0.000000000
      },
      types: [],
      mail: '',
      password: ''
    }
  }),
  created () {
    if (this.getCookie('typeAccount') == 'TicketInsp') {
      this.$router.replace({ name: 'ScanCode' })
    } else if (this.getCookie('typeAccount') == 'User') {
      alert('Utente già registrato.')
      this.$router.replace({ name: 'Home' })
    } else if (this.getCookie('typeAccount') == 'Manager') {
      this.$router.replace({ name: 'HomeManager' })
    } else if (this.getCookie('typeAccount') == 'Admin') {
      this.$router.replace({ name: 'HomeAdmin' })
    }
  },
  methods: {
    getCookie (name) {
      const cookieArr = document.cookie.split(';')
      for (let i = 0; i < cookieArr.length; i++) {
        const cookiePair = cookieArr[i].split('=')
        if (name == cookiePair[0].trim()) {
          return decodeURIComponent(cookiePair[1])
        }
      }
      return null
    },
    homeauth () {
      // Check fields
      this.$router.replace({ name: 'Home' })
    }
  }
}
</script>

<style scoped>
</style>
